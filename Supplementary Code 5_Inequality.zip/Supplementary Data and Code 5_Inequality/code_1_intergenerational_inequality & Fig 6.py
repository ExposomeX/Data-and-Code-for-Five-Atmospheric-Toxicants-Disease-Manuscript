import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import seaborn as sns
from scipy.ndimage import gaussian_filter1d
import joblib

# ==============================================================================
# Global Publication-Ready Plot Settings
# ==============================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 11
plt.rcParams['figure.dpi'] = 300

# ==============================================================================
# 1. Heatmap with Single Median Frontier Line
# ==============================================================================
def plot_total_burden_heatmap_single_line(df_data, ssp, title_suffix, out_dir, province_order=None):
    """
    Plots a heatmap with a single clear median threshold line.
    """
    print(f"Generating heatmap: {title_suffix}...")
    if df_data.empty: return
    
    df_data.columns = df_data.columns.astype(int)
    df_data = df_data.sort_index(axis=1)
    
    # [Modification: Use externally provided sorting order]
    if province_order is not None:
        # Keep only the provinces in the order list and arrange accordingly
        df_sorted = df_data.reindex(province_order).dropna(how='all')
    else:
        row_means = df_data.mean(axis=1)
        df_sorted = df_data.loc[row_means.sort_values(ascending=False).index]
   
    years = df_sorted.columns.values
    n_provs = len(df_sorted)
    prov_indices = np.arange(n_provs)
    X, Y = np.meshgrid(years, prov_indices)
    Z = df_sorted.values
    
    # Plot Setup
    fig, ax = plt.subplots(figsize=(6, 8))
    
    # Color mapping
    cmap = plt.cm.RdYlBu_r
    
    # range
    valid_Z = Z[Z > 0]
    vmin, vmax = (np.percentile(valid_Z, 0), np.percentile(valid_Z, 100)) if len(valid_Z) > 0 else (1, 10)
    norm = mcolors.Normalize(vmin=vmin, vmax=vmax)
    
    # Draw Heatmap
    im = ax.pcolormesh(X, Y, Z, cmap=cmap, shading='gouraud', norm=norm)
    
    # A. Determine threshold (Global Median)
    threshold = np.median(Z)
    
    # B. Calculate the boundary position for each year
    boundary_y_indices = []
    
    for col_idx in range(Z.shape[1]): # Iterate through years
        col_data = Z[:, col_idx]
        count_above = np.sum(col_data > threshold)
        # -0.5 to draw the line between the grid cells
        boundary_y_indices.append(count_above - 0.5) 
        
    # C. Smoothing (Optional, for aesthetic flow)
    boundary_smooth = gaussian_filter1d(boundary_y_indices, sigma=2)
    
    # D. Draw the line
    ax.plot(years, boundary_smooth, color='black', linewidth=1.5, linestyle='--', alpha=0.8)
    
    # E. Add label to the center of the line
    mid_idx = len(years) // 2
    ax.text(years[mid_idx], boundary_smooth[mid_idx] + 0.5, 'Median Threshold', 
            color='black', fontsize=10, ha='center', va='bottom', fontweight='bold')
            
    # =================================================================
    # Extract short names for Y-axis
    short_names = [str(i).split(" ")[0] for i in df_sorted.index.tolist()]

    replace_map = {
        'Guangzhou': 'Guangdong',
        'Inner': 'Inner Mongolia',
        'Hong': 'HK'
    }
    df_sorted_short = [replace_map.get(name, name) for name in short_names]
    
    # Axis Beautification
    ax.set_yticks(prov_indices)
    ax.set_yticklabels(df_sorted_short, fontsize=7, ha='right')
    ax.tick_params(axis='y', which='major', pad=8)
    
    tick_years = np.arange(years.min(), years.max() + 1, 10)
    ax.set_xticks(tick_years)
    ax.set_xticklabels(tick_years, fontsize=7)
    ax.set_xlabel('Year', fontsize=9, fontweight='bold', labelpad=12)
    ax.set_xlim(years.min(), years.max())
    
    # Colorbar
    cbar = plt.colorbar(im, ax=ax, pad=0.03, fraction=0.03)
    cbar.set_label('Total Risk Intensity', fontsize=12)
    
    # Title
    plt.title(f'Provincial Total Risk Intensity ({ssp.upper()} - {title_suffix})', 
              fontsize=16, fontweight='bold', pad=20, loc='left')
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    plt.tight_layout()
    
    os.makedirs(out_dir, exist_ok=True)
    fname = f'Heatmap_SingleLine_{ssp}_{title_suffix.replace(" ", "_")}.png'
    save_path = os.path.join(out_dir, fname)
    plt.savefig(save_path, bbox_inches='tight')
    plt.show()
    plt.close()
    print(f"✅ Single-line heatmap saved to: {save_path}")


# ==============================================================================
# 2. Multi-Scenario Intergenerational Comparison
# ==============================================================================
def plot_ssp_scenario_comparison(ssp_dfs_dict, baseline_year=1950, target_cohort=2030):
    """
    Plots the divergent trend of intergenerational risk multipliers under four SSPs.
    
    Args:
    - ssp_dfs_dict: Dictionary, e.g., {'ssp126': df1, 'ssp245': df2, ...}
    - baseline_year: Baseline birth cohort (set as 1.0x)
    - target_cohort: Future cohort to highlight 'policy space' (e.g., 2030)
    """
    print(f"Plotting multi-scenario intergenerational equity comparison (Baseline: {baseline_year} Cohort)...")
    
    # 1. Extract national mean and calculate multipliers relative to baseline year
    multipliers = {}

    reference_ssp = list(ssp_dfs_dict.keys())[0]
    base_val = pd.DataFrame(ssp_dfs_dict[reference_ssp].mean(axis=0)).loc[str(baseline_year)].values[0]
    
    for ssp, df in ssp_dfs_dict.items():
        national_mean = df.mean(axis=0) # Provincial mean -> National mean
        multipliers[ssp] = national_mean / base_val
        
    years = multipliers[reference_ssp].index.values
    years = years.astype(int) # Ensure years are integers for plotting
    # 2. Plot Setup
    fig, ax = plt.subplots(figsize=(11, 6))
    
    # Standard IPCC Color Palette
    ssp_colors = {
        'ssp126': '#1f77b4', 'ssp245': '#ff7f0e', 
        'ssp370': '#2ca02c', 'ssp585': '#d62728'
    }
    ssp_labels = {
        'ssp126': 'SSP1-2.6 (Sustainability)',
        'ssp245': 'SSP2-4.5 (Middle of the Road)',
        'ssp370': 'SSP3-7.0 (Regional Rivalry)',
        'ssp585': 'SSP5-8.5 (Fossil-fueled)'
    }

    # 3. Draw Shaded Area: Policy Space
    if 'ssp126' in multipliers and 'ssp245' in multipliers:
        ax.fill_between(years, multipliers['ssp126'].values, multipliers['ssp245'].values, 
                        color='grey', alpha=0.15, label='Avoidable Intergenerational Inequity (Policy Space)')
    
    # 4. Draw Trajectories
    for ssp in ['ssp585', 'ssp370', 'ssp245', 'ssp126']: # Plot from highest to lowest severity
        if ssp in multipliers:
            ax.plot(years, multipliers[ssp].values, 
                    color=ssp_colors.get(ssp, 'black'), 
                    linewidth=3, label=ssp_labels.get(ssp, ssp.upper()))
            
            # Annotate endpoints
            end_year = years[-1]
            end_val = multipliers[ssp].loc[str(end_year)]
            ax.text(end_year + 1, end_val, f'{end_val:.2f}x', 
                    color=ssp_colors.get(ssp, 'black'), fontweight='bold', va='center')

    # 5. Baseline & Target Cohort Annotation
    ax.axhline(1.0, color='black', linestyle='--', linewidth=1.5)
    
    if target_cohort in years and 'ssp126' in multipliers and 'ssp245' in multipliers:
        val_worst = multipliers['ssp245'].loc[str(target_cohort)]
        val_best = multipliers['ssp126'].loc[str(target_cohort)]
        gap = val_worst - val_best
        
        ax.axvline(target_cohort, color='grey', linestyle=':', alpha=0.8)
        
        # Draw double-headed arrow for the Gap
        ax.annotate('', xy=(target_cohort, val_worst), xytext=(target_cohort, val_best),
                    arrowprops=dict(arrowstyle='<->', color='black', lw=2))

    # 6. Chart Beautification
    ax.set_title('Divergent Futures: Lifetime Environmental Risk Trajectories Under Different SSPs', 
                 fontsize=15, fontweight='bold', pad=20)
    ax.set_xlabel('Birth Cohort (Year)', fontsize=13)
    ax.set_ylabel(f'Lifetime Risk Multiplier\n(Relative to {baseline_year} Cohort)', fontsize=13)
    
    ax.grid(axis='y', linestyle=':', alpha=0.5)
    ax.set_xlim(years[0], years[-1] + 5) # Leave space for endpoint text
    ax.set_ylim(0.8, 1.3)
    sns.despine()
    plt.tight_layout()
    plt.savefig(f'results/SSP_Scenario_Comparison_{baseline_year}_to_{target_cohort}.png', bbox_inches='tight')
    plt.show()


# ==============================================================================
# 3. Life-cycle Risk Accumulation Trajectories
# ==============================================================================
def calculate_and_plot_age_trajectories(spatial_score_dict, ssp, path_name, target_cohorts=[1950, 1980, 2010, 2030], lifespan=70):
    """
    Plots the risk accumulation trajectory across the lifespan for different birth cohorts.
    """
    print("Calculating life-cycle accumulation trajectories...")
    
    available_years = sorted(spatial_score_dict[ssp][path_name].keys())
    max_year = max(available_years)
    min_year = min(available_years)
    
    # Preprocess national yearly mean dictionary for performance
    national_yearly_mean = {}
    for y in available_years:
        raw = spatial_score_dict[ssp][path_name][y]
        val = np.sum(list(raw.values()), axis=0) if isinstance(raw, dict) else raw
        national_yearly_mean[y] = np.nanmean(val) 
        
    trajectories = {}
    
    for b_year in target_cohorts:
        cumulative_risk = []
        current_sum = 0
        
        for age in range(lifespan + 1): # 0 to 70 years old
            calc_year = b_year + age
            # Clamping years to available data
            target_key = max_year if calc_year > max_year else (min_year if calc_year < min_year else calc_year)
            
            yearly_risk = national_yearly_mean.get(target_key, 0)
            current_sum += yearly_risk
            cumulative_risk.append(current_sum)
            
        trajectories[b_year] = cumulative_risk
        
    # Plotting
    plt.figure(figsize=(6, 6))
    colors = sns.color_palette("rocket", len(target_cohorts))
    
    for i, b_year in enumerate(target_cohorts):
        plt.plot(range(lifespan + 1), trajectories[b_year], 
                 label=f'{b_year} Cohort', color=colors[i], linewidth=3)
        
        # Highlight age 20 (Early Adulthood Exposure)
        age_20_val = trajectories[b_year][20]
        plt.scatter(20, age_20_val, color=colors[i], s=50, zorder=5)
    
    plt.axvline(20, color='grey', linestyle='--', alpha=0.5)
    plt.ylim(0, 50)
    plt.title(f'Pace of Risk Accumulation Across Generations ({ssp.upper()})', fontsize=16, fontweight='bold')
    plt.xlabel('Age (Years)', fontsize=14)
    plt.ylabel('Cumulative Environmental Disease Burden', fontsize=14)
    plt.grid(True, linestyle=':', alpha=0.6)
    sns.despine()
    plt.tight_layout()
    plt.savefig(f'results/Age_Trajectories_{ssp}_{path_name}.png', bbox_inches='tight')
    plt.show()

# ==============================================================================
# DATA LOADING & EXECUTION BLOCK
# ==============================================================================
if __name__ == "__main__":
    
    # --- Directory Configuration ---
    EQUIL_DIR = 'results' 
    ssps = ['ssp126','ssp245','ssp370','ssp585']
    for ssp in ssps:
        # --- 1. Load Data for Heatmap ---
        temp_df = pd.read_csv(f'{ssp}_generational_cummulative_eds.csv', index_col=0)
        
        master_province_order = temp_df.mean(axis=1).sort_values(ascending=False).index.tolist()
        print(f"Master order established. Total provinces: {len(master_province_order)}")
        plot_total_burden_heatmap_single_line(
            df_data=temp_df, 
            ssp=f'{ssp}', 
            title_suffix="Risk_Intensity", 
            out_dir=EQUIL_DIR,
            province_order=master_province_order
        )

    # --- 2. Load Data for Scenario Comparison ---
    df_total_ssp126 = pd.read_csv('ssp126_generational_cummulative_eds.csv', index_col=0)
    df_total_ssp245 = pd.read_csv('ssp245_generational_cummulative_eds.csv', index_col=0)
    df_total_ssp370 = pd.read_csv('ssp370_generational_cummulative_eds.csv', index_col=0)
    df_total_ssp585 = pd.read_csv('ssp585_generational_cummulative_eds.csv', index_col=0)
    
    dict_of_results = {
        'ssp126': df_total_ssp126,
        'ssp245': df_total_ssp245,
        'ssp370': df_total_ssp370,
        'ssp585': df_total_ssp585
    }
    
    plot_ssp_scenario_comparison(dict_of_results, baseline_year=1950, target_cohort=2030)

    # --- 3. Load Data for Age Trajectories ---
    print('loading data')
    individual_disease_spatial_score_dict = joblib.load('individual_disease_spatial_score_dict.joblib')
    print("all dictionaries loaded!")

    calculate_and_plot_age_trajectories(
        spatial_score_dict=individual_disease_spatial_score_dict, 
        ssp='ssp245', 
        path_name='EPPD'
    )
# %%

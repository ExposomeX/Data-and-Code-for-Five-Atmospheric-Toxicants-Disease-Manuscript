#%%
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.integrate import trapezoid
from pathlib import Path
# ==============================================================================
# Global Publication-Ready Plot Settings
# ==============================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['figure.dpi'] = 300

# ==============================================================================
# PART 1: Concentration Index (CI) Calculation
# ==============================================================================
def calculate_ci_from_per_capita_risk(df, pop_col, income_col, risk_col):
    """
    Calculates the Concentration Index (CI) based on per capita risk.
    Reference: Methodology adapted from Nature Communications (Jiang et al., 2024).
    """
    # 1. Data Cleaning: Remove unpopulated or invalid grids
    df_clean = df.dropna(subset=[pop_col, income_col, risk_col]).copy()
    df_clean = df_clean[(df_clean[pop_col] > 1.0) & (df_clean[risk_col] >= 0)]
    
    if len(df_clean) < 10:
        return np.nan
        
    # 2. Core Sorting: Strictly by wealth scale (GDP per capita) from poorest to richest
    df_sorted = df_clean.sort_values(by=income_col, ascending=True)
    
    pop = df_sorted[pop_col].values
    risk_per_capita = df_sorted[risk_col].values
    
    # 3. Restore Total: Total grid disease burden = per capita risk * grid population
    total_risk_array = risk_per_capita * pop
    
    # 4. X-axis: Cumulative population share
    cum_pop = np.cumsum(pop)
    total_pop = cum_pop[-1]
    X = np.concatenate([[0], cum_pop / total_pop])
    
    # 5. Y-axis: Cumulative risk burden share
    cum_risk = np.cumsum(total_risk_array)
    total_risk_sum = cum_risk[-1]
    
    if total_risk_sum == 0:
        return np.nan
        
    Y = np.concatenate([[0], cum_risk / total_risk_sum])
    
    # 6. Calculate CI = 1 - 2 * Area under the concentration curve
    area = trapezoid(Y, X)
    ci = 1 - 2 * area
    
    return ci

# ==============================================================================
# PART 2: Visualization Functions
# ==============================================================================
def plot_provincial_ci_heatmap(df_merged, ssp, out_dir="."):
    """Calculates and plots the long-term heatmap of CI across provinces."""
    print(f"[Info] Calculating provincial Concentration Index (CI) for {ssp.upper()}...")
    
    prov_ci_records = []
    years = sorted(df_merged['year'].unique())

    for year in years:
        df_year = df_merged[df_merged['year'] == year]
        for prov_name, group_df in df_year.groupby('Province'):
            ci_val = calculate_ci_from_per_capita_risk(
                df=group_df, pop_col='pop_total', income_col='gdp_per_capita', risk_col='risk'
            )
            prov_ci_records.append({'Year': year, 'Province': prov_name, 'CI': ci_val})

    df_prov_ci = pd.DataFrame(prov_ci_records).pivot(index='Province', columns='Year', values='CI')
    df_prov_ci = df_prov_ci.dropna(how='all').interpolate(axis=1).ffill(axis=1).bfill(axis=1)
    df_prov_ci_smooth = df_prov_ci.rolling(window=10, axis=1, min_periods=1, center=True).mean()

    exclude_list = ['Hong Kong', 'Taiwan', 'HK', 'TW']
    mask = ~df_prov_ci_smooth.index.isin(exclude_list)
    df_filtered = df_prov_ci_smooth.loc[mask]

    row_means = df_filtered.loc[:, 2020:2100].mean(axis=1)
    df_sorted = df_filtered.loc[row_means.sort_values(ascending=False).index]
    
    # Format short names for Y-axis
    short_names = []
    for name in df_sorted.index.tolist():
        short_name = name.split(" ")[0] if " " in name else name
        if short_name == "Inner": short_name = "Inner Mong." 
        short_names.append(short_name)

    X_years = df_sorted.columns.values
    Y_index = np.arange(len(df_sorted))
    X, Y = np.meshgrid(X_years, Y_index)
    Z = df_sorted.values

    # Plotting
    fig, ax = plt.subplots(figsize=(6, 8)) 
    vmin_val, vmax_val = np.nanmin(Z), np.nanmax(Z)

    if vmin_val >= 0:
        cmap, vmin_plot, vmax_plot = plt.cm.Reds, 0, vmax_val 
    else:
        cmap = plt.cm.coolwarm
        limit = max(abs(vmin_val), abs(vmax_val))
        vmin_plot, vmax_plot = -limit, limit

    im = ax.pcolormesh(X, Y, Z, cmap=cmap, shading='gouraud', vmin=vmin_plot, vmax=vmax_plot, alpha=0.9)
    levels = np.linspace(vmin_plot, vmax_plot, 15)
    contours = ax.contour(X, Y, Z, levels=levels, colors='black', linewidths=0.8, alpha=0.6)
    ax.clabel(contours, inline=True, fontsize=6, fmt='%1.2f', colors='black')
    
    ax.set_yticks(Y_index)
    ax.set_yticklabels(short_names, fontsize=8, fontfamily='sans-serif')
    ax.set_xlabel('Year', fontsize=10, fontweight='bold')
    ax.set_xlim(X_years.min(), X_years.max())
    
    cbar = plt.colorbar(im, ax=ax, pad=0.02, fraction=0.04, aspect=20)
    cbar.set_label('Concentration Index (CI)', fontsize=10, rotation=270, labelpad=15)
    
    plt.title(f'Long-term Evolution of Environmental Inequity ({ssp.upper()})', fontsize=12, fontweight='bold', pad=15)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    plt.tight_layout()
    save_path = os.path.join(out_dir, f'CI_Inequality_Heatmap_{ssp}.png')
    plt.savefig(save_path)
    plt.close()
    print(f"[Success] Heatmap saved to {save_path}")

def plot_national_ci_trend(df_merged, ssp, out_dir="."):
    """Calculates and plots the national annual Concentration Index (CI)."""
    print(f"[Info] Calculating national CI trend for {ssp.upper()}...")
    national_ci_results = []
    
    for year in sorted(df_merged['year'].unique()):
        ci_val = calculate_ci_from_per_capita_risk(
            df=df_merged[df_merged['year'] == year],
            pop_col='pop_total', income_col='gdp_per_capita', risk_col='risk'
        )
        national_ci_results.append({'Year': year, 'National_CI': ci_val})

    df_ci_trend = pd.DataFrame(national_ci_results).set_index('Year')

    plt.figure(figsize=(10, 6))
    x_years, y_ci = df_ci_trend.index, df_ci_trend['National_CI']

    plt.plot(x_years, y_ci, color='#d62728', linewidth=2.5, marker='o', markersize=4, zorder=3, label='Concentration Index')
    plt.fill_between(x_years, 0, y_ci, where=(y_ci <= 0), color='#ff9896', alpha=0.3, zorder=2)
    plt.fill_between(x_years, 0, y_ci, where=(y_ci > 0), color='#aec7e8', alpha=0.3, zorder=2)

    plt.title(f'Evolution of National Environmental Disease Burden Inequity\n({ssp.upper()})', fontsize=15, fontweight='bold', pad=15)
    plt.xlabel('Year', fontsize=13, fontweight='bold')
    plt.ylabel('Concentration Index (CI)', fontsize=13, fontweight='bold')
    
    plt.grid(True, linestyle=':', alpha=0.6)
    sns.despine()

    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, f'National_CI_Trend_{ssp}.png'))
    plt.close()

def plot_dual_perspective_injustice_gap(df_merged, ssp, target_year=2050, out_dir="."):
    """Dual-perspective analysis identifying Environmental Privilege vs. Victims."""
    print(f"[Info] Generating Dual-Perspective Injustice Gap for {target_year} ({ssp.upper()})...")
    
    def get_stats(df, sort_col):
        df_sorted = df.sort_values(by=sort_col, ascending=True).copy()
        df_sorted['pop_cum_pct'] = df_sorted['pop_total'].cumsum() / df_sorted['pop_total'].sum()
        df_sorted['Decile'] = pd.cut(df_sorted['pop_cum_pct'], bins=np.linspace(0, 1, 11), labels=np.arange(1, 11))
        
        stats = df_sorted.groupby('Decile', observed=True).apply(lambda x: pd.Series({
            'gdp_share': (x['gdp_per_capita'] * x['pop_total']).sum(),
            'eds_share': (x['risk'] * x['pop_total']).sum()
        })).reset_index()
        
        stats['gdp_share'] = (stats['gdp_share'] / stats['gdp_share'].sum()) * 100
        stats['eds_share'] = (stats['eds_share'] / stats['eds_share'].sum()) * 100
        stats['gap'] = stats['gdp_share'] - stats['eds_share']
        return stats

    df_year = df_merged[df_merged['year'] == target_year].copy()
    stats_by_income = get_stats(df_year, 'gdp_per_capita')
    stats_by_risk = get_stats(df_year, 'risk')

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6), sharey=True)
    
    # Panel A: Ranked by Income
    colors1 = ['#e34a33' if v < 0 else '#31a354' for v in stats_by_income['gap']]
    ax1.bar(stats_by_income['Decile'], stats_by_income['gap'], color=colors1, alpha=0.8, edgecolor='black')
    ax1.set_title('Perspective A: Ranked by Income\n(Identifying "Environmental Privilege")', fontsize=13, fontweight='bold')
    ax1.set_xlabel('Income Deciles (Poorest → Richest)', fontsize=12)
    
    # Panel B: Ranked by Risk
    colors2 = ['#e34a33' if v < 0 else '#31a354' for v in stats_by_risk['gap']]
    ax2.bar(stats_by_risk['Decile'], stats_by_risk['gap'], color=colors2, alpha=0.8, edgecolor='black')
    ax2.set_title('Perspective B: Ranked by Risk\n(Identifying "Environmental Victims")', fontsize=13, fontweight='bold')
    ax2.set_xlabel('Risk Deciles (Lowest → Highest Risk)', fontsize=12)

    for ax in [ax1, ax2]:
        ax.axhline(0, color='black', linewidth=1.2)
        ax.set_ylabel('Injustice Gap (% GDP Share - % EDS Share)', fontsize=11, fontweight='bold')
        ax.grid(axis='y', linestyle=':', alpha=0.6)
        for bar in ax.patches:
            h = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2, h + (0.5 if h > 0 else -2.5), 
                    f'{h:.1f}%', ha='center', va='bottom', fontsize=10, fontweight='semibold')

    plt.suptitle(f'Comprehensive Environmental Injustice Analysis ({target_year}, {ssp.upper()})', fontsize=16, fontweight='bold', y=1.05)
    sns.despine()
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, f'Injustice_Gap_Dual_{target_year}_{ssp}.png'), bbox_inches='tight')
    plt.close()

def process_and_plot_aging_effects(df_merged, df_aging, ssp, out_dir="."):
    """Integrates aging data, calculates Delta CI, and plots the decomposition."""
    print(f"[Info] Integrating population aging data for {ssp.upper()}...")
    
    # 1. Merge aging data
    ssp_upper = ssp[:4].upper()
    df_aging_sub = df_aging[df_aging['ssp'] == ssp_upper][['Province', 'year', 'aging_rate']].copy()
    df_aging_sub['aging_rate'] = df_aging_sub['aging_rate'] / 100.0

    df_merged = pd.merge(df_merged, df_aging_sub, on=['Province', 'year'], how='left')
    df_merged['aging_rate'] = df_merged['aging_rate'].fillna(0)
    df_merged['risk_aging'] = df_merged['risk'] * df_merged['aging_rate']

    # 2. Calculate National CI for Decomposition
    print("[Info] Calculating National CI to decompose aging effects...")
    national_ci_records = []
    
    for year in sorted(df_merged['year'].unique()):
        df_year = df_merged[df_merged['year'] == year]
        
        # Case 1: Exposure only
        ci_base = calculate_ci_from_per_capita_risk(
            df=df_year, pop_col='pop_total', income_col='gdp_per_capita', risk_col='risk'
        )
        # Case 2: Exposure + Aging
        ci_aging = calculate_ci_from_per_capita_risk(
            df=df_year, pop_col='pop_total', income_col='gdp_per_capita', risk_col='risk_aging'
        )
        
        national_ci_records.append({
            'Year': year, 
            'Case 1:\nExposure Only': ci_base, 
            'Case 2:\n+ Population Aging': ci_aging
        })

    df_national_ci = pd.DataFrame(national_ci_records)
    mean_ci = df_national_ci.drop(columns=['Year']).mean()

    # 3. Plotting: Line Chart (Left) + Bar Chart (Right)
    print("[Info] Generating CI Decomposition Plot (PNAS style)...")
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5), gridspec_kw={'width_ratios': [2.5, 1]})
    color_base, color_aging = '#5ab4ac', '#3f3568'
    
    # Left Panel: Trend Line
    x_years = df_national_ci['Year']
    y_base = df_national_ci['Case 1:\nExposure Only']
    y_aging = df_national_ci['Case 2:\n+ Population Aging']

    ax1.plot(x_years, y_base, marker='o', markersize=4, linewidth=2, color=color_base, label='Case 1: Exposure Only')
    ax1.plot(x_years, y_aging, marker='o', markersize=4, linewidth=2, color=color_aging, label='Case 2: + Population Aging')
    ax1.fill_between(x_years, y_base, y_aging, color=color_aging, alpha=0.1)
    
    ax1.set_xlabel('Year', fontsize=11, fontweight='bold')
    ax1.set_ylabel('Concentration Index (CI)', fontsize=11, fontweight='bold')
    ax1.set_xlim(x_years.min() - 2, x_years.max() + 2)
    ax1.grid(True, linestyle=':', alpha=0.6)
    ax1.legend(loc='upper left', frameon=False, fontsize=10)
    ax1.set_title('Evolution of National CI', fontsize=12, pad=10)

    # Right Panel: Mean Contribution Bar
    bars = ax2.bar(mean_ci.index, mean_ci.values, color=[color_base, color_aging], width=0.5)
    for bar in bars:
        yval = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2, yval + (max(mean_ci.values) * 0.02), f'{yval:.3f}',
                 ha='center', va='bottom', fontsize=10, fontweight='bold')

    ax2.set_title('Mean Contribution', fontsize=12, pad=10)

    # Global Formatting
    y_min = 0 if min(y_base.min(), y_aging.min()) >= 0 else min(y_base.min(), y_aging.min()) * 1.2
    y_max = max(y_base.max(), y_aging.max()) * 1.2
    ax1.set_ylim(y_min, y_max)
    ax2.set_ylim(y_min, y_max)

    for ax in [ax1, ax2]:
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['left'].set_linewidth(1.2)
        ax.spines['bottom'].set_linewidth(1.2)

    fig.suptitle(f'National Environmental Disease Burden Inequity ({ssp.upper()})', fontsize=14, fontweight='bold', y=1.02)
    plt.tight_layout()
    
    save_path = os.path.join(out_dir, f'Aging_Decomposition_CI_{ssp}.png')
    plt.savefig(save_path, bbox_inches='tight')
    plt.close()
    print(f"[Success] Aging decomposition plot saved to {save_path}")

# ==============================================================================
# MAIN EXECUTION PIPELINE
# ==============================================================================
if __name__ == "__main__":
    # --- File Paths Configuration ---
    current_dir = Path(__file__).parent
    BASE_DIR = current_dir
    AGING_FILE_PATH = (current_dir / "../population_summary_all_provinces.csv").resolve()
    OUTPUT_DIR = './output_plots'
    
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Load aging data once
    try:
        df_aging_master = pd.read_csv(AGING_FILE_PATH)
    except Exception as e:
        print(f"[Error] Failed to load aging data: {e}")
        df_aging_master = None

    # Target Scenarios
    ssps = ['ssp126', 'ssp245', 'ssp370', 'ssp585'] 
    
    for ssp in ssps:
        print(f"\n{'='*50}\nExecuting Analysis Pipeline for: {ssp.upper()}\n{'='*50}")
        file_path = os.path.join(BASE_DIR, f'ci_inequality_for_heatmap_{ssp}.csv')
        
        try:
            df_merged = pd.read_csv(file_path)
        except Exception as e:
            print(f"[Error] File not found for {ssp}: {e}. Skipping.")
            continue
            
        # 1. Provincial CI Heatmap
        plot_provincial_ci_heatmap(df_merged, ssp, OUTPUT_DIR)
        
        # 2. National CI Trend Line
        plot_national_ci_trend(df_merged, ssp, OUTPUT_DIR)
        
        # 3. Dual-Perspective Injustice Gap (Target Year: 2050)
        plot_dual_perspective_injustice_gap(df_merged, ssp, target_year=2050, out_dir=OUTPUT_DIR)
        
        # 4. Aging Data Integration and Decomposition Plotting
        if df_aging_master is not None:
            process_and_plot_aging_effects(df_merged, df_aging_master, ssp, out_dir=OUTPUT_DIR)
            
    print("\n All Analysis and Visualization Tasks Completed Successfully!")
# %%

#!/usr/bin/env python
# -*- coding: utf-8 -*-
#%%
"""
Global Benzo[a]pyrene (BaP) Projection Pipeline (1850-2100)

This pipeline performs continuous, seamless predictions of global surface BaP
concentrations across four Shared Socioeconomic Pathways (SSPs). It serves as a 
core module for long-term spatiotemporal reconstruction and health impact assessments.

Methodological Highlights:
- TimeSeries Cross-Validation with true R² scoring.
- Exact SHAP value computation for global feature importance.
- Historical Baseline Anchoring: Preprocessing statistics (mean, std, min, max) are 
  calculated exclusively on the shared historical period (1850-2014) to ensure strict 
  alignment of historical trajectories prior to scenario divergence.
"""

import gc
import pickle
import logging
from pathlib import Path
from typing import Tuple, Dict, List

import shap
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
from xgboost import XGBRegressor
from sklearn.model_selection import TimeSeriesSplit
from tqdm import tqdm

import warnings
warnings.filterwarnings("ignore")

# =============================================================================
# Pipeline Configuration
# =============================================================================
class Config:
    # Temporal & Spatial Constants
    INITIAL_TRAIN_MONTHS = 96
    TEST_MONTHS = 24
    TOTAL_CV_MONTHS = 120
    HIST_MONTHS = 1980  # 1850-2014 (165 years * 12 months)
    TOTAL_PROJ_MONTHS = 3012
    YEARS = 251
    H, W = 180, 360
    
    # Model Constants
    N_CV_SPLITS = 5
    SMALL_CONST = 1e-8
    TEST_SAMPLE_SIZE = 5000
    BACKGROUND_SIZE = 100
    BATCH_SIZE = 100000
    
    # Scenarios
    SSPS = ['ssp126', 'ssp245', 'ssp370', 'ssp585']
    SSP_LABELS = ['SSP1-2.6', 'SSP2-4.5', 'SSP3-7.0', 'SSP5-8.5']
    SSP_COLORS = ['#1f78b4', '#33a02c', '#ff7f00', '#e31a1c']
    
    # Features
    METEOR_NAMES = ['tas', 'huss', 'psl', 'sfcWind', 'bldep']
    SPECIES = ['bc', 'oc', 'nox']
    DEPARTMENTS = ['agr', 'ene', 'ind', 'tra', 'rco', 'slv', 'wst', 'shp']
    
    FEATURE_NAMES = (
        METEOR_NAMES + 
        [f'bc_{dept}' for dept in DEPARTMENTS] +
        [f'nox_{dept}' for dept in DEPARTMENTS] +
        [f'oc_{dept}' for dept in DEPARTMENTS]
    )
    N_FEATURES = len(FEATURE_NAMES)

    # Directories

    ROOT_DIR = Path(__file__).resolve().parent
    TRAIN_DATA_DIR = ROOT_DIR / 'Data Source' / '1998-2007'
    PROJ_DATA_DIR = ROOT_DIR / 'Data Source' / '1850-2100' 
    
    OUT_DIR = ROOT_DIR / 'results' / 'bap_projection_pipeline'
    FOLD_PRED_DIR = OUT_DIR / "fold_preds"
    MODEL_DIR = OUT_DIR / "models"
    SHAP_DIR = OUT_DIR / "shap"
    CV_DIR = OUT_DIR / "cv_results"
    PROJ_OUT_DIR = OUT_DIR / "projections"
    FIG_DIR = OUT_DIR / "figures"

# =============================================================================
# Pipeline Execution Class
# =============================================================================
class BaPProjectionPipeline:
    
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self._setup_logging()
        self._create_directories()
        self.hist_stats = {}
        self.final_model = None

    def _setup_logging(self):
        """Initializes standardized publication-grade logging."""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s [%(levelname)s] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        self.log = logging.getLogger(__name__)

    def _create_directories(self):
        """Ensures all output directories exist."""
        dirs = [self.cfg.FOLD_PRED_DIR, self.cfg.MODEL_DIR, self.cfg.SHAP_DIR, 
                self.cfg.CV_DIR, self.cfg.PROJ_OUT_DIR, self.cfg.FIG_DIR]
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)

    # -------------------------------------------------------------------------
    # Phase 1: Training & Evaluation (1998-2007)
    # -------------------------------------------------------------------------
    def load_training_data(self) -> Tuple[np.ndarray, np.ndarray]:
        """Loads and stacks meteorological and emission training data."""
        self.log.info("Loading 1998-2007 training matrices...")
        
        meteor_files = [
            'tas_ensemble_mean_1998_2007_180x360.npy',
            'huss_ensemble_mean_1998_2007_180x360.npy',
            'psl_ensemble_mean_1998_2007_180x360.npy',
            'sfcWind_ensemble_mean_1998_2007_180x360.npy',
            'bldep_ensemble_mean_1998_2007_180x360.npy'
        ]
        
        meteor_data = [np.load(self.cfg.TRAIN_DATA_DIR / f) for f in meteor_files]
        
        emission_data = []
        for sp in self.cfg.SPECIES:
            for dept in self.cfg.DEPARTMENTS:
                file_path = self.cfg.TRAIN_DATA_DIR / sp / f"{dept}_1998_2007_180x360.npy"
                emission_data.append(np.load(file_path))
                
        X = np.stack(meteor_data + emission_data, axis=1)
        y = np.load(self.cfg.TRAIN_DATA_DIR / 'bapc_120x180x360.npy')
        
        self.log.info(f"Raw training matrices loaded. X: {X.shape}, y: {y.shape}")
        return X, y

    def preprocess_training_data(self, X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Applies log transformations and scaling to the training phase arrays."""
        self.log.info("Preprocessing training data...")
        X_proc = np.zeros_like(X, dtype=np.float32)
        
        # Meteor
        for c, name in enumerate(self.cfg.METEOR_NAMES):
            arr = X[:, c]
            if name in ['tas', 'psl']:
                X_proc[:, c] = (arr - arr.mean()) / (arr.std() + self.cfg.SMALL_CONST)
            elif name in ['huss', 'sfcWind']:
                mn, mx = arr.min(), arr.max()
                X_proc[:, c] = (arr - mn) / (mx - mn + self.cfg.SMALL_CONST)
            elif name == 'bldep':
                X_proc[:, c] = np.log10(np.clip(arr, 0, None) + self.cfg.SMALL_CONST)
                
        # Emissions
        for c in range(5, self.cfg.N_FEATURES):
            arr = np.clip(X[:, c], 0, None)
            X_proc[:, c] = np.log10(arr + self.cfg.SMALL_CONST)
            
        y_proc = np.log10(np.clip(y, 0, None) + self.cfg.SMALL_CONST)
        return X_proc, y_proc

    def train_and_evaluate(self):
        """Executes TimeSeries CV, Trains final model, and outputs SHAP."""
        X, y = self.load_training_data()
        X_proc, y_proc = self.preprocess_training_data(X, y)
        
        # Flatten monthly spatial grids into tabular formats
        X_months = [X_proc[t].reshape(self.cfg.N_FEATURES, -1).T for t in range(self.cfg.TOTAL_CV_MONTHS)]
        y_months = [y_proc[t].ravel() for t in range(self.cfg.TOTAL_CV_MONTHS)]
        
        X_train_full = np.vstack(X_months[:self.cfg.INITIAL_TRAIN_MONTHS])
        y_train_full = np.concatenate(y_months[:self.cfg.INITIAL_TRAIN_MONTHS])
        X_test_all = X_months[self.cfg.INITIAL_TRAIN_MONTHS:]
        y_test_all = y_months[self.cfg.INITIAL_TRAIN_MONTHS:]

        # Free memory
        del X, y, X_proc, y_proc
        gc.collect()

        # --- TimeSeries Cross-Validation ---
        tscv = TimeSeriesSplit(n_splits=self.cfg.N_CV_SPLITS)
        val_r2_scores = []
        fold_preds = []
        
        self.log.info(f"Initiating {self.cfg.N_CV_SPLITS}-Fold TimeSeries CV")
        
        for fold, (train_idx, val_idx) in enumerate(tscv.split(range(self.cfg.INITIAL_TRAIN_MONTHS))):
            X_tr = np.vstack([X_months[i] for i in train_idx])
            y_tr = np.concatenate([y_months[i] for i in train_idx])
            X_val = np.vstack([X_months[i] for i in val_idx])
            y_val = np.concatenate([y_months[i] for i in val_idx])
            
            model = XGBRegressor(
                n_estimators=300, learning_rate=0.05, max_depth=8,
                subsample=0.8, colsample_bytree=0.8, tree_method='hist',
                device='cuda' if fold < self.cfg.N_CV_SPLITS else 'cpu',
                random_state=42, n_jobs=-1
            )
            model.fit(X_tr, y_tr)
            
            val_r2 = r2_score(y_val, model.predict(X_val))
            val_r2_scores.append(val_r2)
            self.log.info(f"Fold {fold+1} Validation R²: {val_r2:.5f}")
            
            fold_pred_3d = np.stack([model.predict(xt).reshape(self.cfg.H, self.cfg.W) for xt in X_test_all])
            fold_preds.append(fold_pred_3d)

        # Log CV Results
        pd.DataFrame({'Fold': [f'Fold_{i+1}' for i in range(self.cfg.N_CV_SPLITS)], 'Val_R2': val_r2_scores})\
            .to_csv(self.cfg.CV_DIR / "cv_validation_r2.csv", index=False)
            
        # Ensemble Test Prediction
        ensemble_pred = np.mean(np.stack(fold_preds), axis=0)
        true_3d = np.stack(y_test_all).reshape(self.cfg.TEST_MONTHS, self.cfg.H, self.cfg.W)
        
        np.save(self.cfg.FOLD_PRED_DIR / "ensemble_pred.npy", ensemble_pred)
        np.save(self.cfg.FOLD_PRED_DIR / "true_log.npy", true_3d)

        # --- Final Model Training ---
        self.log.info("Training unified final model on all 96 months")
        self.final_model = XGBRegressor(
            n_estimators=300, learning_rate=0.05, max_depth=8,
            subsample=0.8, colsample_bytree=0.8, tree_method='hist',
            device='cpu', random_state=42, n_jobs=-1
        )
        self.final_model.fit(X_train_full, y_train_full)
        
        model_path = self.cfg.MODEL_DIR / "xgb_final_best_model.pkl"
        with open(model_path, "wb") as f:
            pickle.dump(self.final_model, f)
            
        self._run_shap_analysis(X_train_full, X_test_all)

    def _run_shap_analysis(self, X_train_full: np.ndarray, X_test_all: List[np.ndarray]):
        """Executes exact SHAP value computation using background distributions."""
        self.log.info("Executing SHAP interpretability analysis...")
        
        bg_idx = np.random.choice(len(X_train_full), self.cfg.BACKGROUND_SIZE, replace=False)
        background_data = X_train_full[bg_idx]
        
        X_test_flat = np.vstack(X_test_all)
        test_idx = np.random.choice(X_test_flat.shape[0], self.cfg.TEST_SAMPLE_SIZE, replace=False)
        test_sample = X_test_flat[test_idx]
        
        explainer = shap.Explainer(self.final_model.predict, background_data)
        shap_values_obj = explainer(test_sample)
        shap_values = shap_values_obj.values

        # Export Feature Importance
        shap_importance = np.mean(np.abs(shap_values), axis=0)
        pd.DataFrame({
            'feature': self.cfg.FEATURE_NAMES,
            'shap_importance': shap_importance
        }).sort_values('shap_importance', ascending=False)\
          .to_csv(self.cfg.SHAP_DIR / "shap_global_importance.csv", index=False)

        # Summary Plot
        shap.summary_plot(shap_values_obj, test_sample, feature_names=self.cfg.FEATURE_NAMES, show=False)
        plt.title("SHAP Summary: Global Feature Importance", fontweight='bold')
        plt.tight_layout()
        plt.savefig(self.cfg.SHAP_DIR / "shap_summary.png", dpi=300, bbox_inches='tight')
        plt.close()

    # -------------------------------------------------------------------------
    # Phase 2: Historical Alignment & Projection (1850-2100)
    # -------------------------------------------------------------------------
    def compute_shared_historical_statistics(self):
        """Computes reference normalization statistics from the 1850-2014 period."""
        self.log.info("Computing shared preprocessing statistics (1850-2014 baseline)...")
        ref_ssp = 'ssp245' 
        ref_data = []

        # Load Meteorological History
        for name in self.cfg.METEOR_NAMES:
            path = self.cfg.PROJ_DATA_DIR / "meteor" / f"{name}_{ref_ssp}_1850_2100_full.npy"
            ref_data.append(np.load(path)[:self.cfg.HIST_MONTHS])

        self.hist_stats = {
            'tas_mean': ref_data[0].mean(), 'tas_std': ref_data[0].std(),
            'psl_mean': ref_data[2].mean(), 'psl_std': ref_data[2].std(),
            'huss_min': ref_data[1].min(), 'huss_max': ref_data[1].max(),
            'sfcWind_min': ref_data[3].min(), 'sfcWind_max': ref_data[3].max(),
        }
        del ref_data
        gc.collect()

    def preprocess_projected_meteor(self, arr: np.ndarray, name: str) -> np.ndarray:
        """Applies fixed historical baseline statistics to future meteorological matrices."""
        if name == 'tas':
            return (arr - self.hist_stats['tas_mean']) / (self.hist_stats['tas_std'] + self.cfg.SMALL_CONST)
        elif name == 'psl':
            return (arr - self.hist_stats['psl_mean']) / (self.hist_stats['psl_std'] + self.cfg.SMALL_CONST)
        elif name == 'huss':
            mn, mx = self.hist_stats['huss_min'], self.hist_stats['huss_max']
            return (arr - mn) / (mx - mn + self.cfg.SMALL_CONST)
        elif name == 'sfcWind':
            mn, mx = self.hist_stats['sfcWind_min'], self.hist_stats['sfcWind_max']
            return (arr - mn) / (mx - mn + self.cfg.SMALL_CONST)
        elif name == 'bldep':
            return np.log10(np.clip(arr, 0, None) + self.cfg.SMALL_CONST)
        return arr

    def run_scenario_projections(self):
        """Loops through all SSPs, generating continuous 1850-2100 surface grids."""
        if self.final_model is None:
            with open(self.cfg.MODEL_DIR / "xgb_final_best_model.pkl", "rb") as f:
                self.final_model = pickle.load(f)

        global_annual_all = {}

        for ssp in self.cfg.SSPS:
            self.log.info(f"Initiating full-period projection for: {ssp.upper()}")
            full_features = []

            # 1. Load and Standardize Meteo
            for name in self.cfg.METEOR_NAMES:
                path = self.cfg.PROJ_DATA_DIR / "meteor" / f"{name}_{ssp}_1850_2100_full.npy"
                data = np.load(path)
                full_features.append(self.preprocess_projected_meteor(data, name))

            # 2. Load and Log-Transform Emissions
            for sp in self.cfg.SPECIES:
                for dept in self.cfg.DEPARTMENTS:
                    path = self.cfg.PROJ_DATA_DIR / "emission" / sp / f"{dept}_{ssp}_1850_2100_full.npy"
                    data = np.log10(np.clip(np.load(path), 0, None) + self.cfg.SMALL_CONST)
                    full_features.append(data)

            # 3. Batch Projection Mapping
            pred_log = np.zeros((self.cfg.TOTAL_PROJ_MONTHS, self.cfg.H, self.cfg.W), dtype=np.float32)
            
            for m in tqdm(range(self.cfg.TOTAL_PROJ_MONTHS), desc=f"Predicting {ssp.upper()}"):
                stack = np.stack([full_features[c][m] for c in range(self.cfg.N_FEATURES)], axis=0)
                X_batch = stack.reshape(self.cfg.N_FEATURES, -1).T
                
                preds = np.empty(X_batch.shape[0], dtype=np.float32)
                for start in range(0, len(X_batch), self.cfg.BATCH_SIZE):
                    end = min(start + self.cfg.BATCH_SIZE, len(X_batch))
                    preds[start:end] = self.final_model.predict(X_batch[start:end])
                
                pred_log[m].ravel()[:] = preds

            del full_features
            gc.collect()

            # 4. Inverse Transform and Temporal Aggregation
            pred_conc = np.clip(10 ** pred_log - self.cfg.SMALL_CONST, 0, None)
            np.save(self.cfg.PROJ_OUT_DIR / f"pred_{ssp}_1850_2100_monthly.npy", pred_conc.astype(np.float32))
            
            annual_global = pred_conc.mean(axis=(1, 2)).reshape(self.cfg.YEARS, 12).mean(axis=1)
            global_annual_all[ssp] = annual_global
            
        self.plot_scenario_divergence(global_annual_all)

    def plot_scenario_divergence(self, global_annual_all: Dict[str, np.ndarray]):
        """Generates publication-ready visualizations of scenario divergence."""
        self.log.info("Rendering global temporal trend visualizations...")
        
        plt.rcParams['font.family'] = 'Arial'
        years = np.arange(1850, 2101)
        
        fig, ax = plt.subplots(figsize=(11, 7), dpi=300)
        
        for ssp, label, color in zip(self.cfg.SSPS, self.cfg.SSP_LABELS, self.cfg.SSP_COLORS):
            ax.plot(years, global_annual_all[ssp], color=color, linewidth=2.5, label=label)

        # Plot Styling
        ax.axvspan(1850, 2014, color='gray', alpha=0.15, label='Shared Historical Target (1850-2014)')
        ax.axvline(x=2014.5, color='black', linestyle='--', linewidth=1.5)
        
        ax.set_xlabel('Year', fontsize=14, fontweight='bold')
        ax.set_ylabel('Global Mean Surface BaP Concentration (ng m$^{-3}$)', fontsize=14, fontweight='bold')
        ax.set_title('Spatiotemporal Projection of Surface BaP Concentration (1850–2100)', 
                     fontsize=16, fontweight='bold', pad=15)
        
        ax.legend(fontsize=12, loc='upper left', frameon=True, edgecolor='black')
        ax.grid(True, linestyle=':', alpha=0.6)
        ax.set_xlim(1848, 2102)
        
        # Save Formats
        plt.tight_layout()
        plt.savefig(self.cfg.FIG_DIR / "Fig_BaP_Global_Projection_1850_2100.png", bbox_inches='tight')
        plt.savefig(self.cfg.FIG_DIR / "Fig_BaP_Global_Projection_1850_2100.pdf", bbox_inches='tight')
        plt.close()

# =============================================================================
# Execution Block
# =============================================================================
if __name__ == "__main__":
    config = Config()
    pipeline = BaPProjectionPipeline(config)
    
    # Phase 1: Train, Evaluate, SHAP
    pipeline.train_and_evaluate()
    
    # Phase 2: Historical Alignment & Scenario Projection
    pipeline.compute_shared_historical_statistics()
    pipeline.run_scenario_projections()
# %%

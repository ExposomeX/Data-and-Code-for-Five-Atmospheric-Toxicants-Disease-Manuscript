import pandas as pd
import numpy as np
import geopandas as gpd
import matplotlib.pyplot as plt
import os
import glob
from pathlib import Path
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import warnings

warnings.filterwarnings('ignore')

# ==============================================================================
# Configuration & Paths
# ==============================================================================
# Base Paths (Adjust as needed)
BASE_DIR = Path(__file__).parent
SHP_PATH = BASE_DIR / "china_shp/geoBoundaries-CHN-ADM1.shp"
TRUE_DIR = (BASE_DIR / '../2.1.1 Data Source/HM Conc data/metal_monthly_2015_2017').resolve()            # Ground truth datasets
OUT_DIR = BASE_DIR / 'code1_results'             # Output directory
GEO_DIR = (TRUE_DIR / '../Gridded concentrations of trace elements in different scenarios.xlsx').resolve()
os.makedirs(OUT_DIR,exist_ok=True)
# Target Regions (Anchor provinces for bias estimation)
TARGET_REGIONS = [
    'Shandong Province', 'Shanxi Province', 'Hebei Province',
    'Henan Province', 'Beijing Municipality', 'Tianjin Municipality'
]

# Unit conversion
UNIT_DIVISOR = 1000.0 

# Global Plotting Styles
plt.rcParams['font.sans-serif'] = ['Arial', 'Times New Roman']
plt.rcParams['axes.unicode_minus'] = False

# ==============================================================================
# Utility Functions
# ==============================================================================
def attach_region_optimized(df, gdf_shp, name_col='shapeName'):
    """
    Spatial join to map grid points to specific administrative boundaries.
    Optimized by pre-filtering the shapefile to target regions.
    """
    gdf_pts = gpd.GeoDataFrame(
        df, 
        geometry=gpd.points_from_xy(df['longitude'], df['latitude']),
        crs="EPSG:4326"
    )
    # Subset shapefile to target regions for faster spatial intersection
    gdf_target = gdf_shp[gdf_shp[name_col].isin(TARGET_REGIONS)][[name_col, 'geometry']]
    joined = gpd.sjoin(gdf_pts, gdf_target, how="left", predicate="intersects")
    return joined

def plot_correction_performance(y_true, y_pred, metal, factor, save_path):
    """Generates a publication-ready scatter plot for the correction baseline."""
    plt.figure(figsize=(6, 6))
    plt.scatter(y_pred, y_true, alpha=0.7, edgecolor='k', linewidth=0.5, color='#2ca02c', s=50, label='Monthly Mean (Target Regions)')
    
    r2 = r2_score(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    
    # Determine dynamic axes limits for a perfect square plot
    max_val = max(np.max(y_true), np.max(y_pred))
    min_val = min(np.min(y_true), np.min(y_pred))
    pad = (max_val - min_val) * 0.05
    limit_min, limit_max = min_val - pad, max_val + pad
    
    if metal =='As':
        plot_ticks = [0.005,0.012] 
        limit_min = 0.005
        limit_max = 0.012
    elif metal =='Cd':
        plot_ticks = [0.001,0.0025]
        limit_min = 0.001
        limit_max = 0.0025
    elif metal == 'Cr':
        plot_ticks = [0.0045,0.012]  
        limit_min = 0.0045
        limit_max = 0.012
    else:
        plot_ticks = [0.03,0.10]
        limit_min = 0.03
        limit_max = 0.1 
    plt.xlim(limit_min, limit_max)
    plt.ylim(limit_min, limit_max)
    plt.yticks(plot_ticks)
    plt.xticks(plot_ticks)
    # 1:1 Reference Line
    plt.plot([limit_min, limit_max], [limit_min, limit_max], 'r--', linewidth=2, label='1:1 Reference')
    
    # Metrics Text Box
    text_str = f"$R^2$: {r2:.3f}\nRMSE: {rmse:.3f}"
    plt.text(limit_min + pad, limit_max - pad*3, text_str, fontsize=11,
             bbox=dict(boxstyle="round,pad=0.4", facecolor="white", edgecolor="gray", alpha=0.9))
    
    plt.xlabel(r'Corrected Prediction ($\mu g/m^3$)', fontweight='bold')
    plt.ylabel(r'Ground Truth ($\mu g/m^3$)', fontweight='bold')
    plt.title(f'Calibration Performance: {metal.upper()}', fontweight='bold', fontsize=13)
    plt.legend(loc='lower right', frameon=True)
    #plt.grid(True, linestyle='--', alpha=0.5)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()

# ==============================================================================
# Main Pipeline
# ==============================================================================
if __name__ == '__main__':
    
    # Load foundational geodata once outside the loop
    print(">>> [Phase 1] Loading Geodata and Shapefiles...")
    gdf_shp = gpd.read_file(SHP_PATH).to_crs("EPSG:4326")
    geo_data = pd.read_excel(GEO_DIR)
    
    # Pre-extract coordinates for later use
    base_coords = geo_data[['latitude', 'longitude']].copy()
    # Round coordinates slightly to prevent floating-point precision issues during merges
    base_coords['lat_round'] = base_coords['latitude'].round(5)
    base_coords['lon_round'] = base_coords['longitude'].round(5)
    
    # Define target metals 
    target_metals = ['As', 'Cd', 'Cr', 'Pb'] 
    
    for metal in target_metals:
        print(f"\n{'='*50}")
        print(f" Executing Global Calibration for: {metal.upper()}")
        print(f"{'='*50}")
        
        # 1. Prepare Prediction Data
        pred_file = (BASE_DIR / f'../1.1.2 Reconstruction methodology/code2_results/{metal}/Projected_Concentrations.csv').resolve()
        if not pred_file.exists():
            print(f"Missing prediction file for {metal}. Skipping.")
            continue
            
        df_pred_raw = pd.read_csv(pred_file)
        df_pred_all = pd.concat([base_coords, df_pred_raw], axis=1)
        
        print(">>> Masking target regions for predictions...")
        df_pred_labeled = attach_region_optimized(df_pred_all, gdf_shp, 'shapeName')
        df_pred_subset = df_pred_labeled[df_pred_labeled['shapeName'].notna()].copy()
        print(f"    Valid prediction grid points in target regions: {len(df_pred_subset)}")

        # 2. Establish Ground Truth Coordinate Mapping
        # Use the first available file to extract the spatial structure
        true_files = sorted(glob.glob(str(TRUE_DIR / 'predicted_2015_*.csv')))
        if not true_files:
            raise FileNotFoundError("Ground truth files missing in the specified directory.")
            
        df_true_ref = pd.read_csv(true_files[0])
        print(">>> Establishing spatial index for ground truth...")
        df_true_labeled_ref = attach_region_optimized(df_true_ref, gdf_shp, 'shapeName')
        df_true_coord_map = df_true_labeled_ref[['latitude', 'longitude', 'shapeName']].dropna()
        # Create rounding keys for robust merging
        df_true_coord_map['lat_round'] = df_true_coord_map['latitude'].round(5)
        df_true_coord_map['lon_round'] = df_true_coord_map['longitude'].round(5)

        # 3. Time Series Aggregation (36 Months)
        print(">>> Aggregating monthly spatial means (2015-2017)...")
        paired_values = [] 
        
        for year in range(2015, 2018):
            for month in range(1, 13):
                time_col = f"{year}_{month:02d}"     # e.g., 201501
                file_suffix = f"{year}_{month:02d}" # e.g., 2015_01
                
                if time_col not in df_pred_subset.columns:
                    continue
                
                # A. Mean Prediction across target regions
                current_pred_mean = df_pred_subset[time_col].mean()
                
                # B. Mean Ground Truth across target regions
                true_file_path = TRUE_DIR / f'predicted_{file_suffix}.csv'
                if not true_file_path.exists():
                    continue
                    
                df_true_curr = pd.read_csv(true_file_path)
                df_true_curr['lat_round'] = df_true_curr['latitude'].round(5)
                df_true_curr['lon_round'] = df_true_curr['longitude'].round(5)
                
                # Robust merge using rounded coordinates
                df_true_matched = df_true_curr.merge(
                    df_true_coord_map[['lat_round', 'lon_round']], 
                    on=['lat_round', 'lon_round'], 
                    how='inner'
                )
                
                val_col = f'{metal}_model'
                if val_col not in df_true_matched.columns:
                    continue
                    
                current_true_mean = (df_true_matched[val_col] / UNIT_DIVISOR).mean()
                
                paired_values.append({
                    'Month': time_col,
                    'Pred_Mean_Target': current_pred_mean,
                    'True_Mean_Target': current_true_mean
                })
                print(f"    - {time_col}: Pred = {current_pred_mean:.4e} | True = {current_true_mean:.4e}")

        # 4. Compute Global Correction Factor
        if not paired_values:
            print(f"No matching temporal data found for {metal}. Skipping correction.")
            continue
            
        df_pairs = pd.DataFrame(paired_values)
        
        global_true_avg = df_pairs['True_Mean_Target'].mean()
        global_pred_avg = df_pairs['Pred_Mean_Target'].mean()
        GLOBAL_FACTOR = global_true_avg / global_pred_avg

        print("\n>>> [Calibration Summary]")
        print(f"    Target Area True Mean (3-yr): {global_true_avg:.4e}")
        print(f"    Target Area Pred Mean (3-yr): {global_pred_avg:.4e}")
        print(f"    Derived Global Scaling Factor: {GLOBAL_FACTOR:.5f}")

        # 5. Apply Factor Domain-Wide
        print(f">>> Applying scaling factor ({GLOBAL_FACTOR:.5f}) to entire domain (2012-2017)...")
        df_final = df_pred_all.copy()
        
        pred_cols = [c for c in df_final.columns if c.startswith('20')] 
        for col in pred_cols:
            df_final[col] = df_final[col] * GLOBAL_FACTOR
            
        # 6. Evaluate and Visualize
        true_array = df_pairs['True_Mean_Target']
        corrected_pred_array = df_pairs['Pred_Mean_Target'] * GLOBAL_FACTOR
        
        plot_correction_performance(
            y_true=true_array, 
            y_pred=corrected_pred_array, 
            metal=metal, 
            factor=GLOBAL_FACTOR, 
            save_path=OUT_DIR / f'{metal}_Calibration_Performance.png'
        )
        
        # Clean up dataframe before saving (remove helper columns)
        df_final = df_final.drop(columns=['lat_round', 'lon_round'], errors='ignore')
        
        # 7. Save Final Adjusted Data
        out_path = OUT_DIR / f'{metal}_2012-2017_prediction_global_corrected.csv'
        df_final.to_csv(out_path, index=False)
        print(f">>> SUCCESS: Calibrated dataset saved to {out_path.name}")

print("\n>>> All correction tasks completed successfully!")
# %%

# ==============================================================================
# Monthly Extrapolation (1950-2100)
# ==============================================================================
import pandas as pd
import numpy as np
import os
import joblib
import traceback
import warnings
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import RandomizedSearchCV
from sklearn.decomposition import PCA
from xgboost import XGBRegressor, XGBClassifier
from scipy.stats import randint, uniform

warnings.filterwarnings('ignore')

# Global Plot Settings for Academic Journals
plt.rcParams['font.sans-serif'] = ['Arial', 'Times New Roman']
plt.rcParams['axes.unicode_minus'] = False

# ---- Configuration ----
script_dir = Path(__file__).resolve().parent

# ---- Directory Setup ----
BASE_DIR = (script_dir / "../2.1.1 Data Source").resolve()
CONC_DATA_DIR = BASE_DIR / 'HM Conc data'
CLI_DATA_DIR = BASE_DIR / 'Meteorological Drivers'
EMI_DATA_DIR = BASE_DIR / 'Anthro emi inventories'
Y_DATA_DIR = (script_dir / "../2.1.3 Calibration of Modeled Metal Concentrations Using Regional Observations/code1_results").resolve()
OUTPUT_BASE_DIR = script_dir / 'code2_results'
os.makedirs(OUTPUT_BASE_DIR, exist_ok=True)

# ==============================================================================
# Part 1: Feature Engineering & Modeling Utilities
# ==============================================================================

def hyperparameter_tuning(X_train, y_train, model_type='regressor', n_iter=20):
    """Randomized Search CV for XGBoost Hyperparameter Optimization."""
    print(f"\n>>> Initiating Hyperparameter Tuning ({model_type.upper()})...")
    
    base_params = {
        'n_estimators': randint(50, 300),
        'max_depth': randint(3, 10),
        'learning_rate': uniform(0.01, 0.3),
        'subsample': uniform(0.4, 0.6), # Fixed uniform distribution ranges
        'colsample_bytree': uniform(0.4, 0.6),
        'reg_alpha': uniform(0, 1),
        'reg_lambda': uniform(0, 1)
    }
    
    if model_type == 'regressor':
        model = XGBRegressor(random_state=42, n_jobs=-1)
        scoring = 'r2'
    else:
        model = XGBClassifier(random_state=42, n_jobs=-1)
        scoring = 'accuracy'
    
    random_search = RandomizedSearchCV(
        model, param_distributions=base_params, n_iter=n_iter,
        cv=3, scoring=scoring, random_state=42, n_jobs=-1, verbose=0
    )
    
    random_search.fit(X_train, y_train)
    print(f"    Best Params: {random_search.best_params_}")
    print(f"    Best Score: {random_search.best_score_:.4f}")
    
    return random_search.best_estimator_

def get_small_const_for_column(col_data, factor=0.1, fallback=1e-20):
    """Derive a small offset for log transformation based on column distribution."""
    pos_vals = col_data[col_data > 0]
    return float(pos_vals.min() * factor) if len(pos_vals) > 0 else fallback
    
def data_process_monthly(train, val, feature_names, save_stats=False):
    """Normalize and transform features, isolating log-sensitive columns."""
    pollutant_prefixes = ('BC', 'OC', 'NOx')
    log_name = [c for c in train.columns if c.endswith(pollutant_prefixes) or c in ['pr']]
    remain_name = ['target']
    time_name = ['year']
    
    # Min-Max Scale Time
    t_min, t_max = train[time_name].min(), train[time_name].max()
    train[time_name] = (train[time_name] - t_min) / (t_max - t_min)
    val[time_name] = (val[time_name] - t_min) / (t_max - t_min)
    
    names_to_remove = set(log_name + remain_name + time_name)  
    scaler_name = [name for name in feature_names if name not in names_to_remove]
    
    # Log Transform
    for col in log_name:
        sc = get_small_const_for_column(train[col], factor=0.1)
        train[col] = np.log10(train[col] + sc)
        val[col] = np.log10(val[col] + sc) 
    
    # Standard Scale
    scaler = StandardScaler()
    train[scaler_name] = scaler.fit_transform(train[scaler_name])
    val[scaler_name] = scaler.transform(val[scaler_name])
    
    return train, val

# ==============================================================================
# Part 2: Forward Modeling & Forecasting Logic
# ==============================================================================
def global_train_predict_yearly(data, pred_year, ssp, model_path, direction='Forward', 
                                window_years=6, site_col='site_id', tune_hyperparams=False):
    """Core function: Two-Stage XGBoost Training for Forward Rolling Forecast."""
    train_start_year = pred_year - window_years
    train_end_year = pred_year - 1
    
    print(f"\n    -> Predicting: {pred_year} | Training Window: {train_start_year} to {train_end_year}")

    train_mask = (data['year'] >= train_start_year) & (data['year'] <= train_end_year)
    val_mask   = (data['year'] == int(pred_year))

    train_df = data[train_mask].copy()
    val_df   = data[val_mask].copy()

    # Gap Filling for Missing Sites
    all_sites = data[site_col].unique()
    if not val_df.empty and set(val_df[site_col]) != set(all_sites):
        missing_sites = set(all_sites) - set(val_df[site_col])
        fill_rows = [{'site_id': s, 'year': pred_year, 'month': m} 
                     for s in missing_sites for m in sorted(val_df['month'].unique())]
        val_df = pd.concat([val_df, pd.DataFrame(fill_rows)], ignore_index=True)

    combined = pd.concat([train_df, val_df], ignore_index=True)
    train_org = combined.iloc[:len(train_df)].copy()
    val_org   = combined.iloc[len(train_df):].copy()

    feature_names = [c for c in train_org.columns if c != 'target']
    train, val = data_process_monthly(train_org, val_org, feature_names)

    drop_cols = ['year', 'month', site_col, 'month_rad']
    train = train.drop(columns=[c for c in drop_cols if c in train.columns], errors='ignore')
    val   = val.drop(columns=[c for c in drop_cols if c in val.columns], errors='ignore')
    feature_names = [c for c in train.columns if c != 'target']

    X_train, y_train = train[feature_names], train['target']
    X_val = val[feature_names]
    model_save_path = os.path.join(model_path, f"pred_{pred_year}_model_{direction}_{ssp}.pkl")

    # The Zero-Inflated Model Architecture
    if (y_train > 0).all():
        y_reg = np.log(y_train + 1e-8)
        reg = hyperparameter_tuning(X_train, y_reg, 'regressor') if tune_hyperparams else \
              XGBRegressor(n_estimators=100, learning_rate=0.05, max_depth=6, subsample=0.8, colsample_bytree=0.8, random_state=42, n_jobs=-1).fit(X_train, y_reg)
        y_class_pred = np.ones(X_val.shape[0], dtype=int)
    else:
        # Stage 1: Classifier for Non-Zero
        y_class = (y_train > 0).astype(int)
        clf = hyperparameter_tuning(X_train, y_class, 'classifier') if tune_hyperparams else \
              XGBClassifier(random_state=42).fit(X_train, y_class)
        y_class_pred = clf.predict(X_val)
        
        # Stage 2: Regressor for Positive Values
        mask = y_train > 0
        X_reg, y_reg = X_train[mask], np.log(y_train[mask] + 1e-8)
        reg = hyperparameter_tuning(X_reg, y_reg, 'regressor') if tune_hyperparams else \
              XGBRegressor(n_estimators=100, learning_rate=0.05, max_depth=6, subsample=0.8, colsample_bytree=0.8, random_state=42, n_jobs=-1).fit(X_reg, y_reg)

    joblib.dump(reg, model_save_path)
    y_reg_pred = reg.predict(X_val)

    # Recombine Predictions
    y_pred = np.where(y_class_pred == 0, 0.0, np.exp(y_reg_pred) - 1e-8)

    result_df = val_org[['year', 'month', site_col]].copy()
    result_df['y_pred'] = y_pred
    result_df['pred_year'] = pred_year 

    return result_df

def rolling_forecast_loop_yearly(DATA, ssp, model_path, start_year=2018, end_year=2100, window_years=6, tune_hyperparams=True):
    """Wrapper for Forward Rolling Forecast."""
    data = DATA.copy()
    all_results = []
    current_year = start_year

    while current_year <= end_year:
        yearly_pred = global_train_predict_yearly(
            data, pred_year=current_year, ssp=ssp, model_path=model_path, 
            direction='Forward', window_years=window_years, tune_hyperparams=tune_hyperparams
        )
        all_results.append(yearly_pred)
        print(f"    [Success] {current_year} Forecasted | Median: {yearly_pred['y_pred'].median():.3e}")

        # Update dataset for the next rolling window
        mask = (data['year'] == current_year)
        if mask.sum() == len(yearly_pred):
            data.loc[mask, 'target'] = yearly_pred['y_pred'].values

        current_year += 1

    return pd.concat(all_results, ignore_index=True)


# ==============================================================================
# Part 3: Backward Modeling & Forecasting Logic (Newly Integrated)
# ==============================================================================
def rolling_forecast_backward_yearly(DATA, ssp, model_path, 
                                     pred_start_year=1950, pred_end_year=2011, 
                                     train_start_year=2012, train_end_year=2017, 
                                     tune_hyperparams=True):
    """Core function: Two-Stage XGBoost Training for Backward (Historical) Forecast."""
    data = DATA.copy()

    # 1. Split Training (Future) and Validation (Past)
    train_mask = (data['year'] >= train_start_year) & (data['year'] <= train_end_year)
    val_mask   = (data['year'] >= pred_start_year) & (data['year'] <= pred_end_year)

    train_df = data[train_mask].copy()
    val_df   = data[val_mask].copy()
    
    print(f"\n    -> Backward Predicting: {pred_start_year}-{pred_end_year} | Training Window: {train_start_year}-{train_end_year}")
    print(f"       Training samples: {len(train_df)}, Prediction samples: {len(val_df)}")

    # 2. Preprocess
    feature_names = [c for c in train_df.columns if c != 'target']
    train_proc, val_proc = data_process_monthly(train_df, val_df, feature_names)

    drop_cols = ['year', 'month', 'site_id', 'month_rad']
    train_proc = train_proc.drop(columns=[c for c in drop_cols if c in train_proc.columns], errors='ignore')
    val_proc   = val_proc.drop(columns=[c for c in drop_cols if c in val_proc.columns], errors='ignore')

    feature_names = [c for c in train_proc.columns if c != 'target']
    X_train, y_train = train_proc[feature_names], train_proc['target']
    X_val = val_proc[feature_names]

    model_save_path = os.path.join(model_path, f"pred_{pred_start_year}_{pred_end_year}_model_backward_{ssp}.pkl")

    # 3. The Zero-Inflated Model Architecture
    if (y_train > 0).all():
        print("    All target values > 0, using Regressor directly.")
        y_reg = np.log(y_train + 1e-8)
        reg = hyperparameter_tuning(X_train, y_reg, 'regressor') if tune_hyperparams else \
              XGBRegressor(n_estimators=100, learning_rate=0.05, max_depth=6, subsample=0.8, colsample_bytree=0.8, random_state=42, n_jobs=-1).fit(X_train, y_reg)
        y_class_pred = np.ones(X_val.shape[0], dtype=int)
    else:
        # Stage 1: Classifier
        y_class = (y_train > 0).astype(int)
        clf = hyperparameter_tuning(X_train, y_class, 'classifier') if tune_hyperparams else \
              XGBClassifier(random_state=42).fit(X_train, y_class)
        y_class_pred = clf.predict(X_val)
        
        # Stage 2: Regressor
        mask = y_train > 0
        X_reg, y_reg = X_train[mask], np.log(y_train[mask] + 1e-8)
        reg = hyperparameter_tuning(X_reg, y_reg, 'regressor') if tune_hyperparams else \
              XGBRegressor(n_estimators=100, learning_rate=0.05, max_depth=6, subsample=0.8, colsample_bytree=0.8, random_state=42, n_jobs=-1).fit(X_reg, y_reg)

    joblib.dump(reg, model_save_path)
    
    # 4. Predict and Recombine
    y_reg_pred = reg.predict(X_val)
    y_pred = np.where(y_class_pred == 0, 0.0, np.exp(y_reg_pred) - 1e-8)

    # 5. Output Packaging
    result_df = val_df[['year', 'month', 'site_id']].copy()
    result_df['y_pred'] = y_pred
    result_df['pred_year'] = result_df['year']

    return result_df


# ==============================================================================
# Data Loading Utility
# ==============================================================================
def npz_read(file_path):
    data = np.load(file_path, allow_pickle=True)
    return pd.DataFrame(data['values'], columns=data['columns'])

def construct_train_data(years, train_history_year, history_emi, history_cli, future_emi, future_cli, geo_features):
    """
    Construct training dataframe.
    `geo_features` should be the strictly sliced dataframe (e.g., .iloc[:,-8:] or PCA reduced columns)
    """
    data_list = []
    for year in years:
        if year in train_history_year:
            emi_df = history_emi[history_emi['year'] == year].iloc[:, 2:-2].reset_index(drop=True)
            cli_df = history_cli[history_cli['year'] == year].iloc[:, 2:-2].reset_index(drop=True)
            time_col = history_cli[history_cli['year'] == year].iloc[:, -2:].reset_index(drop=True)
        else:
            emi_df = future_emi[future_emi['year'] == year].iloc[:, 2:-2].reset_index(drop=True)
            cli_df = future_cli[future_cli['year'] == year].iloc[:, 2:-2].reset_index(drop=True)
            time_col = future_cli[future_cli['year'] == year].iloc[:, -2:].reset_index(drop=True)
        
        geo_repeated = pd.concat([geo_features] * 12, ignore_index=True)
        data = pd.concat([emi_df, cli_df, geo_repeated, time_col], axis=1)
        data_list.append(data)
        
    return pd.concat(data_list, ignore_index=True)

# ==============================================================================
# Main Pipeline Execution
# ==============================================================================
if __name__ == "__main__":
    PREDICT_FUTURE = False
    PREDICT_HISTORY = True
    
    print(">>> Initializing Global Modeling Pipeline...")
    
    heavy_metals = ['As', 'Cd', 'Pb', 'Cr'] 
    print(f"Target Elements: {heavy_metals}")

    geo_data = pd.read_csv(os.path.join(script_dir,'code1_results/df_geo_embeddings.csv'))
    num_sites = geo_data.shape[0] 
    
    train_history_year = [2012, 2013, 2014]
    train_future_year = [2015, 2016, 2017]
    years = train_history_year + train_future_year
    
    history_emi = npz_read(EMI_DATA_DIR/'combined_emi_history_month.npz')
    history_cli = npz_read(CLI_DATA_DIR/'combined_mete_history_month.npz')
    
    for heavy_metal in heavy_metals:
        print(f"\n{'='*60}")
        print(f" Executing Global Pipeline for: {heavy_metal.upper()}")
        print(f"{'='*60}")
        
        y = pd.read_csv(Y_DATA_DIR / f'{heavy_metal}_2012-2017_prediction_global_corrected.csv')
        y = y.iloc[:, 2:]
        Y = pd.DataFrame(np.array(y).T.flatten(), columns=['target'])
        
        file_path = OUTPUT_BASE_DIR / f"pred_{heavy_metal}/files"
        plot_path = OUTPUT_BASE_DIR / f"pred_{heavy_metal}/global_plots"
        model_path = OUTPUT_BASE_DIR / f"pred_{heavy_metal}/models"
        os.makedirs(file_path, exist_ok=True); os.makedirs(plot_path, exist_ok=True); os.makedirs(model_path, exist_ok=True)
       
        all_ssp_results = {}
        
        # ---------------------------------------------------------
        # BLOCK A: PREDICT FUTURE
        # ---------------------------------------------------------
        if PREDICT_FUTURE:
            for ssp in ['ssp126','ssp245','ssp370','ssp585']:
                print(f"\n>>> [FUTURE] Processing Scenario: {ssp.upper()}...")
                
                future_emi = npz_read(EMI_DATA_DIR / f'combined_emi_future_{ssp}_month.npz')
                future_cli = npz_read(CLI_DATA_DIR / f'combined_mete_future_{ssp}_month.npz')
                
                train_data = construct_train_data(years, train_history_year, history_emi, history_cli, future_emi, future_cli, geo_data.iloc[:, -8:])
                
                DATA = pd.concat([train_data, Y], axis=1)
                DATA['site_id'] = np.arange(len(DATA)) % num_sites
                
                # Dynamic Slicing replacing hardcoded values
                geo_repeated = pd.concat([geo_data.iloc[:, -8:]] * (len(future_emi)//num_sites), ignore_index=True)
                FUTURE = pd.concat([future_emi.iloc[:,2:-2].reset_index(drop=True),
                                    future_cli.iloc[:,2:-2].reset_index(drop=True),
                                    geo_repeated.reset_index(drop=True),
                                    future_cli.iloc[:,-2:].reset_index(drop=True)], axis=1)
                FUTURE['target'] = 0
                FUTURE['site_id'] = np.arange(len(FUTURE)) % num_sites
                
                target_end_year = 2100
                # Align to 2018-2100 (2015 starts at index 0)
                months_offset_start = (2018 - 2015) * 12 * num_sites
                months_offset_end = (target_end_year + 1 - 2015) * 12 * num_sites
                FUTURE = FUTURE.iloc[months_offset_start:months_offset_end, :].copy()
                
                dataset = pd.concat([DATA, FUTURE], axis=0).reset_index(drop=True).fillna(0)
                
                print(">>> Executing Forward Rolling Forecast (Yearly)...")
                results = rolling_forecast_loop_yearly(
                    dataset, ssp=ssp, model_path=model_path,
                    start_year=2018, end_year=target_end_year, window_years=6, tune_hyperparams=True
                )
                
                results.to_csv(os.path.join(file_path, f"direct_forecast_all_{ssp}.csv"), index=False)
                all_ssp_results[ssp] = results

        # ---------------------------------------------------------
        # BLOCK B: PREDICT HISTORY (BACKWARD)
        # ---------------------------------------------------------
        if PREDICT_HISTORY:
            print("\n>>> [HISTORY] Processing Historical Reconstructions (1950-2011)...")
            
            # Using ssp245 for future_cli/emi as fallback logic from original block
            future_emi_hist = npz_read(EMI_DATA_DIR / 'combined_emi_future_ssp245_month.npz')
            future_cli_hist = npz_read(CLI_DATA_DIR / 'combined_mete_future_ssp245_month.npz')
            
            # Geo Embeddings PCA
            pca = PCA(n_components=2)  
            geo_reduced = pd.DataFrame(pca.fit_transform(geo_data.iloc[:,-8:]), columns=['geo_pc1','geo_pc2'])
            
            train_data_hist = construct_train_data(years, train_history_year, history_emi, history_cli, future_emi_hist, future_cli_hist, geo_reduced)
            DATA_HIST = pd.concat([train_data_hist, Y], axis=1)
            DATA_HIST['site_id'] = np.arange(len(DATA_HIST)) % num_sites
            
            # Determine correct dynamic offset (1950 to 2014) based on the first dataset
            hist_years_total = 2014 - 1950 + 1
            hist_months_total = hist_years_total * 12
            
            geo_repeated_hist = pd.concat([geo_reduced] * hist_months_total, ignore_index=True)
            
            HISTORY_FULL = pd.concat([
                history_emi.iloc[:,2:-2].reset_index(drop=True),
                history_cli.iloc[:,2:-2].reset_index(drop=True),
                geo_repeated_hist.reset_index(drop=True),
                history_cli.iloc[:,-2:].reset_index(drop=True)
            ], axis=1)
            
            HISTORY_FULL['target'] = 0
            HISTORY_FULL['site_id'] = np.arange(len(HISTORY_FULL)) % num_sites
            
            # Trim the last 3 years (2012, 2013, 2014) as they are in the training loop (3 * 12 months)
            trim_offset = 3 * 12 * num_sites
            history_target_data = HISTORY_FULL.iloc[:-trim_offset, :].copy()
            
            history_dataset = pd.concat([DATA_HIST, history_target_data], axis=0).reset_index(drop=True).fillna(0)
            
            print(">>> Executing Backward Forecast (1950-2011)...")
            results_hist = rolling_forecast_backward_yearly(
                history_dataset,
                ssp='history',
                model_path=model_path,
                pred_start_year=1950,
                pred_end_year=2011,
                train_start_year=2012,
                train_end_year=2017,
                tune_hyperparams=True 
            )
            
            hist_save_path = os.path.join(file_path, "direct_forecast_all_history.csv")
            results_hist.to_csv(hist_save_path, index=False)
            print(f"    [Success] Historical data saved to {hist_save_path}")
# ==============================================================================
# Graph Contrastive Learning for Geographical Spatial Embeddings
# ==============================================================================

import os
import pickle
import csv
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from torch_geometric.data import Data
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import kneighbors_graph
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score
from tqdm import tqdm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import warnings
from pathlib import Path
warnings.filterwarnings('ignore')

# Set random seeds for exact reproducibility
torch.manual_seed(42)
np.random.seed(42)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(42)

# Set device
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f">>> [System] Utilizing computational device: {DEVICE}")

# Global Plot Settings
plt.rcParams['font.sans-serif'] = ['Arial', 'Times New Roman']
plt.rcParams['axes.unicode_minus'] = False

# ==============================================================================
# 1. Graph Neural Network Architecture
# ==============================================================================
class GeoEncoder(nn.Module):
    """
    Multi-layer Graph Convolutional Network (GCN) for extracting latent 
    spatial topological representations from geographic coordinates.
    """
    def __init__(self, input_dim, hidden_dims=[64, 128, 64], output_dim=32, dropout=0.2):
        super(GeoEncoder, self).__init__()
        self.layers = nn.ModuleList()
        
        # Input Layer
        self.layers.append(GCNConv(input_dim, hidden_dims[0]))
        
        # Hidden Layers
        for i in range(len(hidden_dims) - 1):
            self.layers.append(GCNConv(hidden_dims[i], hidden_dims[i + 1]))
            
        # Output Layer
        self.layers.append(GCNConv(hidden_dims[-1], output_dim))
        
        self.dropout = nn.Dropout(dropout)
        
        # Batch Normalization for training stability
        self.batch_norms = nn.ModuleList([
            nn.BatchNorm1d(dim) for dim in hidden_dims
        ])
        
    def forward(self, x, edge_index, edge_weight=None):
        for i, layer in enumerate(self.layers[:-1]):
            x = layer(x, edge_index, edge_weight)
            x = self.batch_norms[i](x)
            x = F.relu(x)
            x = self.dropout(x)
            
        # Final embedding output (no activation)
        x = self.layers[-1](x, edge_index, edge_weight)
        return x

# ==============================================================================
# 2. Graph Construction & Loss Function
# ==============================================================================
def create_geo_graph(lat, lon, k=15, distance_threshold=None, use_distance_weights=True, save_dir=None):
    """Constructs a K-Nearest Neighbor (KNN) spatial graph from coordinates."""
    coords = np.column_stack((lat, lon))
    scaler = StandardScaler()
    coords_scaled = scaler.fit_transform(coords)
    
    if save_dir:
        os.makedirs(save_dir, exist_ok=True)
        with open(os.path.join(save_dir, 'geo_scaler_2012.pkl'), 'wb') as f:
            pickle.dump(scaler, f)
            
    print(f"    -> Constructing Spatial Graph (KNN, k={k})...")
    adjacency = kneighbors_graph(coords_scaled, n_neighbors=k, mode='distance')
    
    if distance_threshold is not None:
        adjacency.data[adjacency.data > distance_threshold] = 0
        adjacency.eliminate_zeros()
        
    # Ensure graph connectivity (handle isolated nodes)
    row_counts = adjacency.getnnz(axis=1)
    isolated_nodes = np.where(row_counts == 0)[0]
    
    if len(isolated_nodes) > 0:
        print(f"    -> Rectifying {len(isolated_nodes)} isolated nodes...")
        for node in isolated_nodes:
            distances = np.sqrt(np.sum((coords_scaled[node] - coords_scaled) ** 2, axis=1))
            distances[node] = np.inf 
            nearest = np.argmin(distances)
            adjacency[node, nearest] = 1.0
            adjacency[nearest, node] = 1.0 
            
    if use_distance_weights:
        # Convert distance to similarity weight using Gaussian kernel
        sigma = np.mean(adjacency.data) * 0.5 
        adjacency.data = np.exp(-(adjacency.data ** 2) / (2 * sigma ** 2))
        
    coo = adjacency.tocoo()
    edge_index = torch.tensor(np.vstack((coo.row, coo.col)), dtype=torch.long)
    edge_attr = torch.tensor(coo.data, dtype=torch.float) if use_distance_weights else None
    x = torch.tensor(coords, dtype=torch.float)
    
    data = Data(x=x, edge_index=edge_index, edge_attr=edge_attr)
    print(f"    -> Graph Built: {data.num_nodes} nodes, {data.num_edges} edges")
    return data

def contrastive_loss(embeddings, edge_index, edge_attr=None, temperature=0.5, neg_samples=10):
    """
    Graph-based InfoNCE Contrastive Loss.
    Optimized tensor operations to prevent device mismatch and overflow.
    """
    num_nodes = embeddings.shape[0]
    embeddings = torch.nan_to_num(embeddings, nan=0.0, posinf=0.0, neginf=0.0)
    
    src, dst = edge_index
    pos_weights = edge_attr if edge_attr is not None else torch.ones_like(src, dtype=torch.float)
    
    # Calculate positive similarities
    pos_scores = torch.sum(embeddings[src] * embeddings[dst], dim=1) / temperature
    pos_scores = torch.clamp(pos_scores * pos_weights, max=20.0)
    
    sample_size = min(1000, num_nodes)
    sampled_nodes = torch.randperm(num_nodes, device=embeddings.device)[:sample_size]
    
    neg_loss = torch.tensor(0.0, device=embeddings.device)
    
    for i in sampled_nodes:
        mask = (src == i)
        if not mask.any(): continue
            
        connected_nodes = dst[mask]
        edge_scores = pos_scores[mask]
        
        # Negative sampling
        neg_indices = torch.randint(0, num_nodes, (neg_samples,), device=embeddings.device)
        valid_mask = (neg_indices != i) & (~torch.isin(neg_indices, connected_nodes))
        neg_indices = neg_indices[valid_mask]
        
        if len(neg_indices) == 0: continue
            
        neg_scores = torch.sum(embeddings[i].unsqueeze(0) * embeddings[neg_indices], dim=1) / temperature
        neg_scores = torch.clamp(neg_scores, max=20.0)
        
        # InfoNCE formulation with LogSumExp trick for stability
        for pos_score in edge_scores:
            # FIX: Ensure pos_score is promoted to tensor on correct device
            combined_scores = torch.cat([pos_score.unsqueeze(0), neg_scores])
            max_val = torch.max(combined_scores)
            
            pos_exp = torch.exp(pos_score - max_val)
            neg_exp_sum = torch.sum(torch.exp(neg_scores - max_val))
            
            neg_loss += -torch.log(pos_exp / (pos_exp + neg_exp_sum + 1e-8))
            
    return neg_loss / sample_size

# ==============================================================================
# 3. Main Pre-training Execution
# ==============================================================================
if __name__ == '__main__':
    print("\n" + "="*60)
    print(" Phase 0: Initializing Geographical Representation Encoder")
    print("="*60)
    
    # [USER CONFIG]
    base_dir = Path(__file__).parent
    
    input_file = (base_dir / '../2.1.1 Data Source/HM Conc data/Gridded concentrations of trace elements in different scenarios.xlsx').resolve()
    output_dir = base_dir/ 'code1_results_check'
    os.makedirs(output_dir, exist_ok=True)
    
    print(">>> Loading geographic coordinate corpus...")
    df = pd.read_excel(input_file)
    lat, lon = df['latitude'].values, df['longitude'].values
    print(f"    Total geographic points: {len(df)}")
    
    geo_graph = create_geo_graph(lat, lon, k=15, use_distance_weights=True, save_dir=output_dir)
    geo_graph = geo_graph.to(DEVICE)
    
    input_dim = geo_graph.x.shape[1]
    model = GeoEncoder(input_dim=input_dim, hidden_dims=[16, 32, 16], output_dim=8).to(DEVICE)
    
    optimizer = torch.optim.Adam(model.parameters(), lr=0.005, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5)
    
    epochs = 100
    best_loss = float('inf')
    patience_counter = 0
    patience = 15 
    loss_history = []
    
    print("\n>>> Commencing Contrastive Pre-training (Unsupervised)...")
    model.train()
    for epoch in tqdm(range(epochs), desc="Training GCN"):
        optimizer.zero_grad()
        
        embeddings = model(geo_graph.x, geo_graph.edge_index, getattr(geo_graph, 'edge_attr', None))
        loss = contrastive_loss(embeddings, geo_graph.edge_index, getattr(geo_graph, 'edge_attr', None))
        
        loss.backward()
        optimizer.step()
        scheduler.step(loss)
        
        loss_history.append(loss.item())
        
        if loss < best_loss:
            best_loss = loss
            patience_counter = 0
            torch.save(model.state_dict(), os.path.join(output_dir, 'best_geo_encoder.pt'))
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f"    -> Early stopping triggered at epoch {epoch+1}")
                break

    # Extract Final Embeddings
    print("\n>>> Extracting Latent Spatial Embeddings...")
    model.load_state_dict(torch.load(os.path.join(output_dir, 'best_geo_encoder.pt')))
    model.eval()
    with torch.no_grad():
        final_embeddings = model(geo_graph.x, geo_graph.edge_index, getattr(geo_graph, 'edge_attr', None)).cpu().numpy()
        
    final_embeddings = np.nan_to_num(final_embeddings, nan=0.0)
    
    # Save Embeddings Dataframe
    embedding_cols = [f'geo_emb_{i}' for i in range(final_embeddings.shape[1])]
    for i, col in enumerate(embedding_cols):
        df[col] = final_embeddings[:, i]
        
    embed_csv_path = os.path.join(output_dir, 'df_geo_embeddings.csv')
    df.to_csv(embed_csv_path, index=False)
    print(f"    -> Embeddings appended and saved to: {os.path.basename(embed_csv_path)}")

    # ==============================================================================
    # 4. Evaluation & Diagnostics (Clustering & t-SNE)
    # ==============================================================================
    print("\n>>> Evaluating Embedding Quality (t-SNE & K-Means)...")
    
    # Plot Training Loss
    plt.figure(figsize=(8, 5))
    plt.plot(loss_history, color='#1f77b4', linewidth=2)
    plt.title('Contrastive Pre-training Loss Convergence', fontweight='bold')
    plt.xlabel('Epoch'); plt.ylabel('InfoNCE Loss')
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.savefig(os.path.join(output_dir, 'geo_training_loss.png'), dpi=300, bbox_inches='tight')
    plt.close()
    
    # Sampling for t-SNE
    sample_size = min(5000, len(final_embeddings))
    indices = np.random.choice(len(final_embeddings), sample_size, replace=False)
    sample_embeddings = final_embeddings[indices]
    
    tsne = TSNE(n_components=2, random_state=42)
    embeddings_2d = tsne.fit_transform(sample_embeddings)
    
    # Cluster Metrics
    cluster_metrics = []
    for n_clusters in range(2, 11):
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        labels = kmeans.fit_predict(sample_embeddings)
        if len(set(labels)) > 1:
            cluster_metrics.append({
                'n_clusters': n_clusters,
                'silhouette': silhouette_score(sample_embeddings, labels),
                'davies_bouldin': davies_bouldin_score(sample_embeddings, labels)
            })
            
    best_cluster = max(cluster_metrics, key=lambda x: x['silhouette'])
    print(f"    -> Optimal Topological Clusters Found: {best_cluster['n_clusters']}")
    
    kmeans_opt = KMeans(n_clusters=best_cluster['n_clusters'], random_state=42, n_init=10)
    opt_labels = kmeans_opt.fit_predict(sample_embeddings)
    
    # Plot clustered t-SNE
    plt.figure(figsize=(9, 7))
    scatter = plt.scatter(embeddings_2d[:, 0], embeddings_2d[:, 1], c=opt_labels, cmap='tab10', alpha=0.7, s=15)
    plt.colorbar(scatter, label='Topological Cluster')
    plt.title('t-SNE Projection of GCN Spatial Embeddings', fontweight='bold')
    plt.xlabel('t-SNE Dimension 1'); plt.ylabel('t-SNE Dimension 2')
    plt.savefig(os.path.join(output_dir, 'geo_embeddings_tsne_clusters.png'), dpi=300, bbox_inches='tight')
    plt.close()

    print(">>> Geo-Encoder Pipeline Completed Successfully!")

# ==============================================================================
# Monthly Validation (2012-2017) & Comprehensive Model Evaluation
# ==============================================================================
import pandas as pd
import numpy as np
import os
import joblib
import traceback
import warnings
import shap
import matplotlib.pyplot as plt
import matplotlib.colors as colors
import seaborn as sns

from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import RandomizedSearchCV
from xgboost import XGBRegressor, XGBClassifier
from scipy.stats import randint, uniform, ks_2samp, wasserstein_distance, spearmanr, gaussian_kde
from pathlib import Path
from dateutil.relativedelta import relativedelta

warnings.filterwarnings('ignore')

# ---- Configuration ----
script_dir = Path(__file__).resolve().parent

# ---- Directory Setup ----
BASE_DIR = (script_dir / "../2.1.1 Data Source").resolve()
CONC_DATA_DIR = BASE_DIR / 'HM Conc data'
CLI_DATA_DIR = BASE_DIR / 'Meteorological Drivers'
EMI_DATA_DIR = BASE_DIR / 'Anthro emi inventories'
Y_DATA_DIR = (script_dir / "../2.1.3 Calibration of Modeled Metal Concentrations Using Regional Observations/code1_results").resolve()
OUTPUT_BASE_DIR = script_dir / 'code3_results'
os.makedirs(OUTPUT_BASE_DIR, exist_ok=True)

# ==============================================================================
# Global Publication-Ready Plot Settings
# ==============================================================================
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 11
plt.rcParams['figure.dpi'] = 300

# ==============================================================================
# Utility Functions
# ==============================================================================
def get_small_const_for_column(col_data, factor=0.1, fallback=1e-20):
    pos_vals = col_data[col_data > 0]
    if len(pos_vals) > 0:
        return float(pos_vals.min() * factor)
    else:
        return fallback

def hyperparameter_tuning(X_train, y_train, model_type='regressor', n_iter=20):
    """
    Perform hyperparameter tuning using RandomizedSearchCV.
    """
    print(f"\nInitiating hyperparameter tuning ({model_type})...")
    
    if model_type == 'regressor':
        model = XGBRegressor(random_state=42, n_jobs=-1)
        param_dist = {
            'n_estimators': randint(50, 300),
            'max_depth': randint(3, 10),
            'learning_rate': uniform(0.01, 0.3),
            'subsample': uniform(0.6, 0.4),
            'colsample_bytree': uniform(0.6, 0.4),
            'reg_alpha': uniform(0, 1),
            'reg_lambda': uniform(0, 1)
        }
        scoring = 'r2'
    else:  # classifier
        model = XGBClassifier(random_state=42, n_jobs=-1)
        param_dist = {
            'n_estimators': randint(50, 300),
            'max_depth': randint(3, 10),
            'learning_rate': uniform(0.01, 0.3),
            'subsample': uniform(0.6, 0.4),
            'colsample_bytree': uniform(0.6, 0.4),
            'reg_alpha': uniform(0, 1),
            'reg_lambda': uniform(0, 1)
        }
        scoring = 'accuracy'
    
    random_search = RandomizedSearchCV(
        model, 
        param_distributions=param_dist,
        n_iter=n_iter,
        cv=3,
        scoring=scoring,
        random_state=42,
        n_jobs=-1,
        verbose=1
    )
    
    random_search.fit(X_train, y_train)
    
    print(f"Optimal Parameters: {random_search.best_params_}")
    print(f"Best Score: {random_search.best_score_:.4f}")
    
    return random_search.best_estimator_

def data_process_monthly(train, val, feature_names, save_stats=True):
    pollutant_prefixes = ('BC', 'OC', 'NOx')
    log_name = [
        col for col in train.columns
        if col.endswith(pollutant_prefixes) or col in ['pr']
    ]
    remain_name = ['target']
    time_name = ['year']
    
    # Min-max normalization for the time dimension
    train_min_year = train[time_name].min()
    train_max_year = train[time_name].max()
    
    train[time_name] = (train[time_name] - train_min_year) / (train_max_year - train_min_year)
    val[time_name] = (val[time_name] - train_min_year) / (train_max_year - train_min_year)
    
    names_to_remove = set(log_name + remain_name + time_name)  
    scaler_name = [name for name in feature_names if name not in names_to_remove]
    
    for col in log_name:
        sc = get_small_const_for_column(train[col], factor=0.1)
        train[col] = np.log10(train[col] + sc)
        val[col] = np.log10(val[col] + sc) 
    
    scaler = StandardScaler()
    train[scaler_name] = scaler.fit_transform(train[scaler_name])
    val[scaler_name] = scaler.transform(val[scaler_name])
    
    if save_stats:
        input_features = log_name + scaler_name
        stats_train = train[input_features].agg(['min', 'max', 'mean', 'median']).T
        stats_val = val[input_features].agg(['min', 'max', 'mean', 'median']).T
        # Optional: Suppressed printing to keep logs clean during iteration
        # print(stats_train)
        # print(stats_val)
        
    return train, val

def global_train_predict(data, pred_year, pred_month, ssp, model_path, direction,
                         window_months=24, site_col='site_id', tune_hyperparams=False, do_shap=False):
    """
    Execute rolling prediction for (pred_year, pred_month) using the preceding N months.
    """
    pred_date = pd.Timestamp(year=pred_year, month=pred_month, day=1)
    train_end = pred_date - relativedelta(months=1)                    
    train_start = pred_date - relativedelta(months=window_months)      

    print(f"\nPredicting for {pred_year}-{pred_month:02d} | Training Window: "
          f"{train_start.strftime('%Y-%m')} ~ {train_end.strftime('%Y-%m')}")

    # Construct training and validation masks
    train_mask = (data['year'] * 12 + data['month'] >= train_start.year * 12 + train_start.month) & \
                 (data['year'] * 12 + data['month'] <= train_end.year * 12 + train_end.month)
    val_mask   = (data['year'] == int(pred_year)) & (data['month'] == int(pred_month))

    train_df = data[train_mask].copy()
    val_df   = data[val_mask].copy()

    if len(train_df) < 1000:
        raise ValueError(f"Insufficient training samples: {len(train_df)}")

    # Ensure all spatial sites are present in the validation month
    all_sites = data[site_col].unique()
    if not val_df.empty and set(val_df[site_col]) != set(all_sites):
        missing_sites = set(all_sites) - set(val_df[site_col])
        print(f"   Imputing {len(missing_sites)} missing sites for validation.")
        missing_rows = pd.DataFrame({
            site_col: list(missing_sites),
            'year': pred_year,
            'month': pred_month
        })
        val_df = pd.concat([val_df, missing_rows], ignore_index=True)

    combined = pd.concat([train_df, val_df], ignore_index=True)
    train_org = combined.iloc[:len(train_df)].copy()
    val_org   = combined.iloc[len(train_df):].copy()

    feature_names = [c for c in train_org.columns if c != 'target']
    train, val = data_process_monthly(train_org, val_org, feature_names, save_stats=False)
    
    drop_cols = ['year', 'month', site_col, 'month_rad', 'ship_OC', 'ship_BC']
    train = train.drop(columns=[c for c in drop_cols if c in train.columns], errors='ignore')
    val   = val.drop(columns=[c for c in drop_cols if c in val.columns], errors='ignore')
    
    feature_names = [c for c in train.columns if c != 'target']
    
    X_train = train[feature_names]
    y_train = train['target']
    X_val   = val[feature_names]

    model_save_path = os.path.join(model_path, f"pred_{pred_year}{pred_month}_model_{direction}_{ssp}.pkl")

    print(f"Training instances: {len(X_train)}, Validation instances: {len(X_val)}, Features: {X_train.shape[1]}")
    
    # --- Model Training Logic ---
    if (y_train > 0).all():
        print("All y_train > 0; skipping classification and proceeding with direct regression.")
        y_reg = np.log(y_train + 1e-8)
        X_reg = X_train
        
        if tune_hyperparams:
            reg = hyperparameter_tuning(X_reg, y_reg, 'regressor')
        else:
            reg = XGBRegressor(n_estimators=100, learning_rate=0.05, max_depth=6,
                               subsample=0.8, colsample_bytree=0.8, random_state=42, n_jobs=-1)
            reg.fit(X_reg, y_reg)
        y_class_pred = np.ones(X_val.shape[0], dtype=int)
    else:
        # Two-stage hurdle model (Classification -> Regression)
        y_class = (y_train > 0).astype(int)
        if tune_hyperparams:
            clf = hyperparameter_tuning(X_train, y_class, 'classifier')
        else:
            clf = XGBClassifier(random_state=42)
            clf.fit(X_train, y_class)
        y_class_pred = clf.predict(X_val)
        
        mask = y_train > 0
        y_reg = np.log(y_train[mask] + 1e-8)
        X_reg = X_train[mask]
        if tune_hyperparams:
            reg = hyperparameter_tuning(X_reg, y_reg, 'regressor')
        else:
            reg = XGBRegressor(n_estimators=100, learning_rate=0.05, max_depth=6,
                               subsample=0.8, colsample_bytree=0.8, random_state=42, n_jobs=-1)
            reg.fit(X_reg, y_reg)

    joblib.dump(reg, model_save_path)
    y_reg_pred = reg.predict(X_val)

    y_pred = np.zeros_like(y_class_pred, dtype=float)
    for i in range(len(y_pred)):
        if y_class_pred[i] == 0:
            y_pred[i] = 0
        else:
            y_pred[i] = np.exp(y_reg_pred[i]) - 1e-8

    result_df = val_org[['year', site_col]].copy()
    result_df['y_pred'] = y_pred
    result_df['pred_year'] = pred_year
    result_df['pred_month'] = pred_month

    return result_df

def validate_year_performance(DATA, val_year=2017, window_months=60, ssp='validation', model_path='./validation'):
    """
    Execute monthly rolling validation for the specified target year.
    """
    print(f"\n{'='*20} Starting Model Validation for {val_year} (Window: {window_months} months) {'='*20}")
    
    validation_results = []
    os.makedirs(model_path, exist_ok=True)

    for month in range(1, 13):
        try:
            monthly_res = global_train_predict(
                data=DATA,
                pred_year=val_year,
                pred_month=month,
                ssp=ssp,
                model_path=model_path,
                direction='Forward',
                window_months=window_months,
                tune_hyperparams=False,
                do_shap=False
            )
            monthly_res['site_id'] = np.arange(0, 28917)
            monthly_res = monthly_res.reset_index(drop=True)
            
            # Re-attach the ground truth (target) to the predictions
            current_true = DATA[(DATA['year'] == val_year) & (DATA['month'] == month)][['site_id', 'target']].copy()
            current_true.rename(columns={'target': 'y_true'}, inplace=True)
            
            merged = pd.merge(monthly_res, current_true, on='site_id', how='left')
            merged['month'] = month
            
            validation_results.append(merged)
            
            r2_month = r2_score(merged['y_true'], merged['y_pred'])
            print(f"[{val_year}-{month:02d}] Prediction completed | R²: {r2_month:.4f} | Samples: {len(merged)}")
            
        except Exception as e:
            print(f"[{val_year}-{month:02d}] Validation failed: {e}")
            traceback.print_exc()

    if not validation_results:
        print("No validation results were generated.")
        return None

    final_df = pd.concat(validation_results, ignore_index=True)    
    return final_df

def construct_train_data(years, train_history_year, history_emi, history_cli, future_emi, future_cli, geo_data):
    data_list = []
    for year in years:
        if year in train_history_year:
            emi_df = history_emi[history_emi['year'] == year].iloc[:, 2:-2].reset_index(drop=True)
            cli_df = history_cli[history_cli['year'] == year].iloc[:, 2:-2].reset_index(drop=True)
            time_col = history_cli[history_cli['year'] == year].iloc[:, -2:].reset_index(drop=True)
        else:
            emi_df = future_emi[future_emi['year'] == year].iloc[:, 2:-2].reset_index(drop=True)
            cli_df = future_cli[future_cli['year'] == year].iloc[:, 2:-2].reset_index(drop=True)
            time_col = future_cli[future_cli['year'] == year].iloc[:, -2:].reset_index(drop=True)
            
        geo_repeated = pd.concat([geo_data.iloc[:, -8:]] * 12, ignore_index=True)
        data = pd.concat([emi_df, cli_df, geo_repeated, time_col], axis=1)
        data_list.append(data)
        
    DATA = pd.concat(data_list, ignore_index=True)
    return DATA

def npz_read(file_path):
    data = np.load(file_path, allow_pickle=True)
    df = pd.DataFrame(data['values'], columns=data['columns'])
    return df

# ==============================================================================
# Advanced Multi-Dimensional Validation (Temporal, Spatial, Distributional)
# ==============================================================================
def comprehensive_validation_analysis(final_data, geo_coords, val_year, heavy_metal, save_dir):
    """
    Generates a comprehensive deep validation report including temporal seasonality,
    probability density alignment, and spatial bias.
    """
    print(f"\n>>> Generating comprehensive validation report for {heavy_metal.upper()} ({val_year})...")
    os.makedirs(save_dir, exist_ok=True)
    
    fig = plt.figure(figsize=(18, 12))
    
    # ---------------------------------------------------------
    # (A) Temporal Seasonality (Monthly Aggregations)
    # ---------------------------------------------------------
    ax1 = plt.subplot(2, 2, 1)
    monthly_stats = final_data.groupby('month')[['y_true', 'y_pred']].agg(['mean', 'std'])
    months = monthly_stats.index
    
    ax1.plot(months, monthly_stats['y_true']['mean'], label='Observed (True)', color='#2ca02c', marker='o', linewidth=2.5)
    ax1.fill_between(months, 
                     monthly_stats['y_true']['mean'] - monthly_stats['y_true']['std'] * 0.5,
                     monthly_stats['y_true']['mean'] + monthly_stats['y_true']['std'] * 0.5, 
                     color='#2ca02c', alpha=0.2)
    
    ax1.plot(months, monthly_stats['y_pred']['mean'], label='Predicted', color='#1f77b4', marker='s', linewidth=2.5, linestyle='--')
    ax1.fill_between(months, 
                     monthly_stats['y_pred']['mean'] - monthly_stats['y_pred']['std'] * 0.5,
                     monthly_stats['y_pred']['mean'] + monthly_stats['y_pred']['std'] * 0.5, 
                     color='#1f77b4', alpha=0.2)
    
    ax1.set_title('(A) Temporal Dynamics: Monthly Averages', fontweight='bold', fontsize=14)
    ax1.set_xlabel('Month', fontsize=12)
    ax1.set_ylabel(r'Concentration ($\mu g/m^3$)', fontsize=12)
    ax1.set_xticks(range(1, 13))
    ax1.legend(loc='upper right', frameon=False)
    ax1.grid(True, linestyle='--', alpha=0.5)

    # ---------------------------------------------------------
    # (B) Probability Density Distribution Matching
    # ---------------------------------------------------------
    ax2 = plt.subplot(2, 2, 2)
    mask = ~np.isnan(final_data['y_true']) & ~np.isnan(final_data['y_pred'])
    y_t_clean = final_data.loc[mask, 'y_true']
    y_p_clean = final_data.loc[mask, 'y_pred']
    
    sns.kdeplot(y_t_clean, ax=ax2, label='Observed', color='#2ca02c', fill=True, alpha=0.3, linewidth=2)
    sns.kdeplot(y_p_clean, ax=ax2, label='Predicted', color='#1f77b4', fill=True, alpha=0.3, linewidth=2)
    
    ax2.set_title('(B) Overall Probability Density Distribution', fontweight='bold', fontsize=14)
    ax2.set_xlabel(r'Concentration ($\mu g/m^3$)', fontsize=12)
    ax2.set_ylabel('Density', fontsize=12)
    
    upper_limit = np.percentile(y_t_clean, 99)
    ax2.set_xlim(0, upper_limit * 1.5)
    ax2.legend(frameon=False)
    ax2.grid(True, linestyle='--', alpha=0.5)

    # ---------------------------------------------------------
    # (C) Spatial Distribution of Mean Bias Error
    # ---------------------------------------------------------
    ax3 = plt.subplot(2, 1, 2) 
    site_bias = final_data.groupby('site_id').apply(
        lambda x: np.mean(x['y_pred'] - x['y_true'])
    ).reset_index(name='bias')
    
    site_geo_bias = pd.merge(site_bias, geo_coords, on='site_id', how='inner')
    
    vmin = np.percentile(site_geo_bias['bias'], 5)
    vmax = np.percentile(site_geo_bias['bias'], 95)
    abs_max = max(abs(vmin), abs(vmax)) 
    
    scatter = ax3.scatter(site_geo_bias['longitude'], site_geo_bias['latitude'], 
                          c=site_geo_bias['bias'], cmap='RdBu_r', 
                          vmin=-abs_max, vmax=abs_max, s=15, alpha=0.8, edgecolor='none')
    
    cbar = plt.colorbar(scatter, ax=ax3, fraction=0.03, pad=0.04)
    cbar.set_label(r'Mean Bias Error (Predicted - Observed)', fontsize=12)
    
    ax3.set_title('(C) Spatial Distribution of Prediction Bias', fontweight='bold', fontsize=14)
    ax3.set_xlabel('Longitude', fontsize=12)
    ax3.set_ylabel('Latitude', fontsize=12)
    ax3.grid(True, linestyle='--', alpha=0.5)

    plt.tight_layout(pad=3.0)
    save_path = os.path.join(save_dir, f'{heavy_metal}_comprehensive_validation_{val_year}.png')
    plt.savefig(save_path, bbox_inches='tight')
    plt.close()
    print(f"Validation report successfully saved to: {save_path}")


# ==============================================================================
# Main Execution Pipeline
# ==============================================================================
if __name__ == "__main__":
    
    heavy_metals = ['As','Pb', 'Cr', 'Cd']
    for heavy_metal in heavy_metals:
        print(f'\n{"="*60}\nInitiating Global Validation for {heavy_metal.upper()}\n{"="*60}')
        val_year = 2017
        
        # --- 1. Data Preparation ---
        y_path = Y_DATA_DIR / f'{heavy_metal}_2012-2017_prediction_global_corrected.csv'
        y = pd.read_csv(y_path).iloc[:, 2:]
        
        assert y.shape[1] == 72, "Target variable DataFrame must contain exactly 72 columns."
        arr = np.array(y)  
        Y = pd.DataFrame(arr.T.flatten(), columns=['target'])
        
        train_history_year = [2012, 2013, 2014]
        train_future_year = [2015, 2016, 2017]
        years = train_history_year + train_future_year
        
        history_emi = npz_read(EMI_DATA_DIR / 'combined_emi_history_month.npz')
        history_cli = npz_read(CLI_DATA_DIR / 'combined_mete_history_month.npz')
        future_emi = npz_read(EMI_DATA_DIR / 'combined_emi_future_ssp245_month.npz')
        future_cli = npz_read(CLI_DATA_DIR / 'combined_mete_future_ssp245_month.npz')
        
        geo_data = pd.read_csv(os.path.join(script_dir,'code1_results/df_geo_embeddings.csv'))
        print(">>> Constructing Feature Space...")
        train_data = construct_train_data(years=years,
                                          train_history_year=train_history_year,
                                          history_emi=history_emi,
                                          history_cli=history_cli,
                                          future_emi=future_emi,
                                          future_cli=future_cli,
                                          geo_data=geo_data)
        
        DATA = pd.concat([train_data, Y], axis=1)
        site_count = geo_data.shape[0] 
        DATA['site_id'] = np.arange(len(DATA)) % site_count
                
        # --- 2. Multi-Year Expanding Window Validation ---
        validation_years = [2015, 2016, 2017] 
        base_train_year = 2012                
        
        all_years_metrics = []   
        all_years_results = []   
        
        for v_year in validation_years:
            # Dynamic window configuration (e.g., 2015 = 2012~2014 = 36 months)
            dynamic_window_months = (v_year - base_train_year) * 12
            
            print(f"\n>>> Executing rolling validation for {v_year} (Training Window: {dynamic_window_months} months)...")
            yearly_val_data = validate_year_performance(
                DATA=DATA,       
                val_year=v_year,           
                window_months=dynamic_window_months, 
                ssp='history_val',
                model_path= OUTPUT_BASE_DIR
            )
            
            if yearly_val_data is None or yearly_val_data.empty:
                continue
                
            y_t = yearly_val_data['y_true'].values
            y_p = yearly_val_data['y_pred'].values
            
            r2 = r2_score(y_t, y_p)
            rmse = np.sqrt(mean_squared_error(y_t, y_p))
            mae = mean_absolute_error(y_t, y_p)
            
            all_years_metrics.append({
                'Year': v_year, 'R2': r2, 'RMSE': rmse, 'MAE': mae
            })
            all_years_results.append(yearly_val_data)
            
            print(f" [*] Validation for {v_year} completed -> R²: {r2:.3f}, RMSE: {rmse:.3f}, MAE: {mae:.3f}")

            # -------------------------------------------------------------
            # High-Fidelity Log-Density Scatter Plot
            # -------------------------------------------------------------
            print(">>> Generating logarithmic point density scatter plot...")
            plt.figure(figsize=(8, 7))
            mask = ~np.isnan(y_t) & ~np.isnan(y_p)
            x_clean, y_clean = y_t[mask], y_p[mask]

            sample_size = min(len(x_clean), 50000)
            idx = np.random.choice(np.arange(len(x_clean)), sample_size, replace=False)
            x_sample, y_sample = x_clean[idx], y_clean[idx]

            xy = np.vstack([x_sample, y_sample])
            kde = gaussian_kde(xy, bw_method=0.1) 
            z = kde(xy)
            idx_sort = z.argsort()
            x_plot, y_plot, z_plot = x_sample[idx_sort], y_sample[idx_sort], z[idx_sort]

            # 1:1 Aspect Ratio Logic
            min_limit = min(x_clean.min(), y_clean.min())
            max_limit = max(x_clean.max(), y_clean.max())
            
            scatter = plt.scatter(x_plot, y_plot, c=z_plot, s=5, cmap='viridis', 
                                  norm=colors.LogNorm(vmin=z_plot.min(), vmax=z_plot.max()), 
                                  alpha=0.6, edgecolor=None, rasterized=True)
            
            plt.colorbar(scatter).set_label('Logarithmic Point Density', fontweight='bold')
            plt.plot([min_limit, max_limit], [min_limit, max_limit], 'r--', lw=2, label='1:1 Reference', zorder=15)
            
            plt.xlabel('Observed Concentration', fontweight='bold')
            plt.ylabel('Predicted Concentration', fontweight='bold')
            plt.title(f'Model Performance: {heavy_metal.upper()} ({v_year})\n$R^2$ = {r2:.3f}, RMSE = {rmse:.3f}', fontweight='bold')
            plt.legend(loc='upper left', frameon=True)
            plt.grid(True, alpha=0.2, linestyle=':')
            
            plt.xlim(min_limit, max_limit)
            plt.ylim(min_limit, max_limit)

            save_dir = OUTPUT_BASE_DIR
            os.makedirs(save_dir, exist_ok=True)
            scatter_save_path = os.path.join(save_dir, f'{heavy_metal}_validation_scatter_{v_year}.png')
            plt.savefig(scatter_save_path, bbox_inches='tight')
            plt.close()
            
            # -------------------------------------------------------------
            # Execution of Spatial/Temporal/Distributional Validation
            # -------------------------------------------------------------
            geo_coords = geo_data[['latitude', 'longitude']].copy()
            geo_coords['site_id'] = np.arange(len(geo_coords))
            
            comprehensive_validation_analysis(
                final_data=yearly_val_data, 
                geo_coords=geo_coords, 
                val_year=v_year, 
                heavy_metal=heavy_metal, 
                save_dir=save_dir
            )
            
        # --- 3. Temporal Robustness Summary (Bar Chart) ---
        final_multi_year_data = pd.concat(all_years_results, ignore_index=True)
        metrics_df = pd.DataFrame(all_years_metrics)
        
        print(f"\n{'='*20} Multi-Year Validation Summary ({heavy_metal.upper()}) {'='*20}")
        print(metrics_df.to_string(index=False))
        
        os.makedirs(save_dir, exist_ok=True)
        fig, ax1 = plt.subplots(figsize=(8, 5))
        
        x = np.arange(len(metrics_df['Year']))
        width = 0.35
        
        # Plot R² (Left Y-Axis)
        rects1 = ax1.bar(x - width/2, metrics_df['R2'], width, label='$R^2$ (Higher is better)', color='#1f77b4', edgecolor='black')
        ax1.set_ylabel('$R^2$ Score', fontweight='bold', color='#1f77b4')
        ax1.tick_params(axis='y', labelcolor='#1f77b4')
        ax1.set_ylim(0, 1.0) 
        
        # Plot RMSE (Right Y-Axis)
        ax2 = ax1.twinx()
        rects2 = ax2.bar(x + width/2, metrics_df['RMSE'], width, label='RMSE (Lower is better)', color='#d62728', edgecolor='black')
        ax2.set_ylabel(r'RMSE ($\mu g/m^3$)', fontweight='bold', color='#d62728')
        ax2.tick_params(axis='y', labelcolor='#d62728')
        
        ax1.set_xticks(x)
        ax1.set_xticklabels(metrics_df['Year'], fontweight='bold', fontsize=12)
        ax1.set_title(f'Temporal Robustness Across Validation Years ({heavy_metal.upper()})', fontweight='bold')
        
        lines_1, labels_1 = ax1.get_legend_handles_labels()
        lines_2, labels_2 = ax2.get_legend_handles_labels()
        ax1.legend(lines_1 + lines_2, labels_1 + labels_2, loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=2, frameon=False)
        
        plt.grid(True, axis='y', linestyle='--', alpha=0.3)
        sns.despine(ax=ax1, right=False)
        plt.tight_layout()
        
        robustness_plot_path = os.path.join(save_dir, f'{heavy_metal}_multiyear_robustness.png')
        plt.savefig(robustness_plot_path, bbox_inches='tight')
        plt.close()
        print(f">>> Temporal robustness chart successfully saved to: {robustness_plot_path}")

        # Save aggregated numerical predictions to CSV
        final_multi_year_data.to_csv(os.path.join(save_dir, f'{heavy_metal}_validation_results.csv'), index=False)
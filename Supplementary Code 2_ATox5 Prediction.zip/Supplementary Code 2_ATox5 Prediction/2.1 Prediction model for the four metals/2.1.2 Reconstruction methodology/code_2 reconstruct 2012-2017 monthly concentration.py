# ==============================================================================
# Random Forest Modeling, SHAP Interpretation, and Spatial Projection
# ==============================================================================
#%%
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.model_selection import train_test_split, GridSearchCV, cross_validate
import matplotlib
matplotlib.use('Agg') # Use non-interactive backend for server rendering
import joblib
import shap
import numpy as np
import pandas as pd
from pathlib import Path
import os
import seaborn as sns
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')

# ---- Configuration ----
script_dir = Path(__file__).resolve().parent

# ---- Directory Setup ----
BASE_DIR = (script_dir / "../2.1.1 Data Source").resolve()
CONC_DATA_DIR = BASE_DIR / 'HM Conc data'
CLI_DATA_DIR = BASE_DIR / 'Meteorological Drivers'
EMI_DATA_DIR = BASE_DIR / 'Anthro emi inventories'
OUTPUT_BASE_DIR = script_dir / 'code2_results'
weights_save_path = (script_dir / '../2.1.2 Reconstruction methodology/code1_results/seasonal_weights.csv').resolve()
os.makedirs(OUTPUT_BASE_DIR, exist_ok=True)

print("\n>>> [Phase 2] Establishing Random Forest Absolute Regression Models...")

# Global font settings for academic plots
plt.rcParams['font.sans-serif'] = ['Arial', 'Times New Roman']
plt.rcParams['axes.unicode_minus'] = False

def load_npz_to_df(file_path):
    """Utility function to load .npz files into pandas DataFrame"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Missing required dataset: {file_path}")
    data = np.load(file_path, allow_pickle=True)
    return pd.DataFrame(data['values'], columns=data['columns'])

# ---- Data Loading ----
print(">>> Loading meteorological and emission datasets...")
try:
    future_emi = load_npz_to_df(os.path.join(EMI_DATA_DIR,'combined_emi_future_ssp245_annual.npz'))
    future_cli = load_npz_to_df(CLI_DATA_DIR / 'combined_mete_future_ssp245_annual.npz')
    history_emi = load_npz_to_df(EMI_DATA_DIR / 'combined_emi_history_annual.npz')
    history_cli = load_npz_to_df(CLI_DATA_DIR / 'combined_mete_history_annual.npz')
    
    future_emi_month = load_npz_to_df(EMI_DATA_DIR / 'combined_emi_future_ssp245_month.npz')
    future_cli_month = load_npz_to_df(CLI_DATA_DIR / 'combined_mete_future_ssp245_month.npz')
    history_emi_month = load_npz_to_df(EMI_DATA_DIR / 'combined_emi_history_month.npz')
    history_cli_month = load_npz_to_df(CLI_DATA_DIR / 'combined_mete_history_month.npz')
except Exception as e:
    print(f"Dataset loading failed: {e}")
    exit(1)

def plot_validation_scatter(y_true, y_pred, title, save_path=None):
    """Generate publication-ready scatter plot for model validation"""
    plt.figure(figsize=(6, 6))
    plt.scatter(y_true, y_pred, alpha=0.5, edgecolor='k', linewidth=0.5, color='#1f77b4')
    
    r2 = r2_score(y_true, y_pred)
    max_val = max(np.max(y_true), np.max(y_pred))
    min_val = min(np.min(y_true), np.min(y_pred))
    padding = (max_val - min_val) * 0.05
    
    plt.xlim(min_val - padding, max_val + padding)
    plt.ylim(min_val - padding, max_val + padding)
    plt.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2) # 1:1 line
    
    plt.text(min_val + padding, max_val - padding*1.2,
             f'$R^2 = {r2:.3f}$', fontsize=12,
             bbox=dict(boxstyle="round,pad=0.3", facecolor="white", edgecolor="gray", alpha=0.9))
    
    plt.xlabel('Observed Value', fontweight='bold')
    plt.ylabel('Predicted Value', fontweight='bold')
    plt.title(title, fontweight='bold')
    plt.grid(True, alpha=0.3, linestyle='--')
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()

def build_3d_features(data_emi, data_cli, year):
    """Construct (Spatial_N, 12_Months, Features) 3D matrix"""
    monthly_frames = []
    for month in range(1, 13):
        m_emi = data_emi[(data_emi['year'] == int(year)) & (data_emi['month'] == int(month))].iloc[:, 2:-2].reset_index(drop=True)
        m_cli = data_cli[(data_cli['year'] == int(year)) & (data_cli['month'] == int(month))].iloc[:, 2:-2].reset_index(drop=True)
        month_data = pd.concat([m_emi, m_cli], axis=1)
        monthly_frames.append(month_data)
    
    data_3d = np.array([df.values for df in monthly_frames])  # Shape: (12, N, F)
    data_3d = data_3d.transpose(1, 0, 2)  # Reshape to: (N, 12, F)
    print(f"   [Data Config] Year {year} matrix shaped to: {data_3d.shape}")
    return data_3d

def train_and_evaluate_rf(X, y, metal_name, month, output_path, select_features=False):
    """Core workflow: Train, evaluate, and extract feature importances."""
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    selected_features = X.columns.tolist()
    
    # Hyperparameter tuning via GridSearchCV
    param_grid = {
        'n_estimators': [100, 200], 
        'max_depth': [5, 10, None]
    }
    rf = RandomForestRegressor(random_state=42, n_jobs=-1)
    gs = GridSearchCV(rf, param_grid, cv=5, scoring='r2', n_jobs=-1, verbose=0)
    gs.fit(X_train, y_train)
    
    best_model = gs.best_estimator_
    y_pred = best_model.predict(X_test)
    
    r2 = r2_score(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    print(f"   - Month {month+1:02d} | Test R²: {r2:.3f} | Test RMSE: {rmse:.3f}")
    
    plot_validation_scatter(y_test, y_pred, f'Model Validation - Month {month+1}',
                            os.path.join(output_path, f'Scatter_Validation_M{month+1}.png'))
    
    return best_model, y_test, y_pred, X_test, selected_features

def execute_temporal_projection(models, target_years, features_dict, output_path):
    """Project concentrations for specified historical/future years."""
    all_projections = []
    months_str = [f"{m:02d}" for m in range(1, 13)]
    
    for year in target_years:
        for m_idx, month in enumerate(months_str):
            is_history = int(year) <= 2014 # CMIP6 historical threshold
            
            curr_emi = history_emi_month if is_history else future_emi_month
            curr_cli = history_cli_month if is_history else future_cli_month
                
            X_emi = curr_emi[(curr_emi['year'] == int(year)) & (curr_emi['month'] == int(month))].iloc[:, 2:-2]
            X_cli = curr_cli[(curr_cli['year'] == int(year)) & (curr_cli['month'] == int(month))].iloc[:, 2:-2]
            X_target = pd.concat([X_emi, X_cli], axis=1).reset_index(drop=True)
            
            X_input = X_target[features_dict[m_idx]]
            
            # Predict and apply physical non-negative constraint
            model = models[m_idx]
            pred = np.maximum(model.predict(X_input.values), 0) 
            
            all_projections.append(pd.DataFrame(pred, columns=[f"{year}_{month}"]))
    
    final_df = pd.concat(all_projections, axis=1)
    final_df.to_csv(os.path.join(output_path, 'Projected_Concentrations.csv'), index=False)
    return final_df

# ---- Main Execution Block ----
if __name__ == '__main__':
    ENABLE_FEATURE_SELECTION = False
    ENABLE_SHAP = True
    
    # Extract feature columns from a sample slice
    X2012_sample = pd.concat([history_emi[history_emi.year==2012].iloc[:,2:-1].reset_index(drop=True), 
                              history_cli[history_cli.year==2012].iloc[:,2:-1].reset_index(drop=True)], axis=1)
    feature_columns = X2012_sample.columns
    
    x_2012 = build_3d_features(history_emi_month, history_cli_month, 2012)
    x_2017 = build_3d_features(future_emi_month, future_cli_month, 2017)
    
    try:
        EXCEL_FILE_PATH = CONC_DATA_DIR / 'Gridded concentrations of trace elements in different scenarios.xlsx'
        y_2012_df = pd.read_excel(EXCEL_FILE_PATH, sheet_name=0)
        y_2017_df = pd.read_excel(EXCEL_FILE_PATH, sheet_name=1)

    except Exception as e:
        print(f"Target variable loading failed: {e}")
        exit(1)
    
    weight_df = pd.read_csv(weights_save_path)
    
    target_metals = ['As', 'Cd', 'Cr', 'Pb']  
    print(f"\n>>> Target Elements Queued: {target_metals}")

    for metal in target_metals:
        element_id = metal.lower()
        print(f"\n{'='*40}")
        print(f" Processing Element: {element_id.upper()}")
        print(f"{'='*40}")
        
        # 1. Construct Monthly Targets using Climatological Weights
        y2012_annual = y_2012_df[element_id].values
        y2017_annual = y_2017_df[element_id].values

        temporal_weight = np.array(weight_df[f'{metal}_model'])
        y2012_monthly = y2012_annual[:, None] * temporal_weight[None, :] * 12 
        y2017_monthly = y2017_annual[:, None] * temporal_weight[None, :] * 12 
        
        # 2. Directory Initialization
        element_out_dir = OUTPUT_BASE_DIR / element_id.upper()
        model_store_dir = element_out_dir / 'Saved_Models'
        os.makedirs(model_store_dir, exist_ok=True)

        trained_models = {}
        monthly_features = {}

        # 3. Monthly Iteration for Model Training
        for month in range(12):
            X_2012_m = pd.DataFrame(x_2012[:, month, :], columns=feature_columns)
            X_2017_m = pd.DataFrame(x_2017[:, month, :], columns=feature_columns)
            
            X_pool = pd.concat([X_2012_m, X_2017_m], axis=0).reset_index(drop=True)
            y_pool = np.concatenate([y2012_monthly[:, month], y2017_monthly[:, month]])

            rf_model, y_test, y_pred, X_test_df, selected_feats = train_and_evaluate_rf(
                X_pool, y_pool, element_id, month, element_out_dir, 
                select_features=ENABLE_FEATURE_SELECTION
            )
            
            trained_models[month] = rf_model
            monthly_features[month] = selected_feats
            joblib.dump(rf_model, model_store_dir / f'RF_Model_M{month+1:02d}.pkl')

            # 4. SHAP Value Calculation & Visualization
            if ENABLE_SHAP:
                explainer = shap.TreeExplainer(rf_model)
                shap_values = explainer.shap_values(X_test_df, approximate=True)
                
                # Calculating net directional impact (mean of raw SHAP values)
                net_shap_impact = np.mean(shap_values, axis=0)  
                sort_idx = np.argsort(np.abs(net_shap_impact))[::-1] # Sort by absolute magnitude

                top_k = min(30, len(net_shap_impact))
                top_features = X_test_df.columns[sort_idx[:top_k]]
                top_shap_vals = net_shap_impact[sort_idx[:top_k]]

                bar_colors = ['#d62728' if val > 0 else '#1f77b4' for val in top_shap_vals]
                plt.figure(figsize=(12, max(6, top_k * 0.35)))

                bars = plt.barh(top_features, top_shap_vals, color=bar_colors, edgecolor='black', linewidth=0.5)

                for bar in bars:
                    width = bar.get_width()
                    label = f"{width:+.2e}"
                    x_offset = width + (1e-7 if width >= 0 else -1e-7)
                    plt.text(x_offset, bar.get_y() + bar.get_height()/2, label,
                             va='center', ha='left' if width >= 0 else 'right',
                             fontsize=9, color='black')
                
                plt.axvline(x=0, color='black', linestyle='-', linewidth=1)
                plt.xlabel('Net Directional SHAP Impact', fontweight='bold')
                plt.title(f'Feature Attribution (Month {month+1})', fontweight='bold')
                plt.ticklabel_format(style='sci', axis='x', scilimits=(0,0))
                plt.gca().invert_yaxis() # Display most important at the top

                plt.tight_layout()
                shap_plot_path = element_out_dir / f'SHAP_Impact_M{month+1:02d}.png'
                plt.savefig(shap_plot_path, dpi=300)
                plt.close()
                
        # 5. Execute Multi-year Projections
        print(f"\n   >>> Executing temporal projection for {element_id.upper()} (2012-2017)...")
        projection_years = [str(y) for y in range(2012, 2018)]
        execute_temporal_projection(trained_models, projection_years, monthly_features, element_out_dir)

print("\n>>> Pipeline execution completed successfully.")

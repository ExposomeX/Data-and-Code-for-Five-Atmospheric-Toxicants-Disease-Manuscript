# ==============================================================================
# Calculation of Climatological Seasonal Weights for Temporal Downscaling
# ==============================================================================
import numpy as np
import pandas as pd
from pathlib import Path
import os
import seaborn as sns
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings('ignore')

# ---- Configuration ----
script_dir = Path(__file__).resolve().parent
# PLEASE ADJUST THE PATH ACCORDING TO YOUR DIRECTORY STRUCTURE
data_folder = script_dir / "../2.1.1 Data Source/HM Conc data/metal_monthly_2015_2017"
data_folder = data_folder.resolve()
output_folder = script_dir / "code1_results"
output_folder.mkdir(exist_ok=True)

YEARS = list(range(2015, 2018))
MONTHS = list(range(1, 13))
POLLUTANTS = ['As', 'Cd', 'Cr', 'Pb']
COL_NAME = [f'{i}_model' for i in POLLUTANTS]

print(">>> [Phase 1] Initiating Climatological Seasonal Weights Calculation...")

# ---- Extract Monthly Means ----
mean_value_month_dict = {}
for year in YEARS:
    for month in MONTHS:
        file_path = data_folder / f'predicted_{year}_{month:02d}.csv'
        if file_path.exists():
            monthly_data = pd.read_csv(file_path)
            mean_value_month_dict[f'{year}_{month:02d}'] = monthly_data[COL_NAME].mean(axis=0)

df_all = pd.DataFrame(mean_value_month_dict).T 
df_all['Month'] = df_all.index.str[-2:].astype(int)

# ---- Calculate Climatological Monthly Mean and Normalize ----
df_monthly_avg = df_all.groupby('Month')[COL_NAME].mean()
seasonal_weights = df_monthly_avg.div(df_monthly_avg.sum(axis=0), axis=1)

# Save results
weights_save_path = data_folder / 'seasonal_weights.csv'
seasonal_weights.to_csv(weights_save_path)
print(f">>> Seasonal weights successfully saved to: {weights_save_path}")

# ---- Visualization: Heatmap & Line Plot ----
seasonal_weights.columns = [c.replace('_model', '') for c in seasonal_weights.columns]
seasonal_weights = seasonal_weights[['As', 'Cd', 'Cr', 'Pb']]

# Plot 1: Heatmap
plt.figure(figsize=(10, 6))
sns.heatmap(seasonal_weights.T, annot=True, fmt=".3f", cmap="YlGnBu", cbar_kws={'label': 'Normalized Weight'})
plt.title('Climatological Seasonal Weights Distribution', fontsize=14, fontweight='bold')
plt.xlabel('Month', fontsize=12)
plt.ylabel('Trace Element', fontsize=12)
plt.savefig(output_folder / 'seasonal_weights_heatmap.png', dpi=300, bbox_inches='tight')
plt.tight_layout()
plt.show()

# Plot 2: Line Plot
plt.figure(figsize=(12, 6))
markers = ['o', 's', '^', 'D'] 
for i, col in enumerate(seasonal_weights.columns):
    plt.plot(seasonal_weights.index, seasonal_weights[col], 
             marker=markers[i % len(markers)], label=col, linewidth=2.5, markersize=8)

plt.title('Monthly Dynamics of Trace Element Weights', fontsize=14, fontweight='bold')
plt.xlabel('Month', fontsize=12)
plt.ylabel('Allocated Weight', fontsize=12)
plt.ylim(0,0.15)
plt.yticks([0,0.05,0.10,0.15])
plt.xticks(range(1, 13))
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', title='Element')
plt.savefig(output_folder / 'seasonal_weights_lineplot.png', dpi=300, bbox_inches='tight')
plt.tight_layout()
plt.show()
"""
=============================================================================
Script Name: Environmental_Disease_Indices_Calculator.py
Description: 
    This script calculates the Environment-Disease Potential (EPD) and 
    Environment-Disease Score (EDS) for anthropogenic airborne toxicants 
    (ATox5) across multiple diseases and emission scenarios (SSPs) in China 
    from 1950 to 2100. It integrates toxicity weights (PDS) derived from 
    E-BIO networks (EPPD and EGoD) with spatial concentration and population data.
=============================================================================
"""
#%%
# ============================== Import Libraries ==============================
import os
import copy
import pickle
import numpy as np
import pandas as pd
import geopandas as gpd
import seaborn as sns
import joblib
from tqdm import tqdm
from pathlib import Path

# ========================== Global Configurations ==========================
METALS = ['cr6', 'as', 'pb', 'cd', 'bap']
REF = {
    'as': 0.006, 'cd': 0.005, 'pb': 0.5, 'cr6': 0.000025, 'bap': 0.001
}

current_dir = Path(__file__).parent
# Path Configurations

PRED_DIR = (current_dir / "../2.2 Concentration Data").resolve()
POP_PATH = (current_dir / "../2.1 Gridded Global Population Dataset").resolve()
# Note: Keep the shapefile name as is if the original file is named in Chinese
SHP_PATH = os.path.join(current_dir,'shp_en')
EXPOSURE_XLSX = (current_dir / "exposure.xlsx").resolve()
OUT_DIR = (current_dir / "output_disease_check").resolve()
EBIO_DIR = (current_dir / "results_pds_score").resolve()

NPZ_DIR = DATA_DIR = os.path.join(OUT_DIR, 'data')
TREND_DIR = os.path.join(OUT_DIR, 'trend_plot')
STACK_DIR = os.path.join(OUT_DIR, 'stack_plot')

# Create directories if they do not exist
os.makedirs(TREND_DIR, exist_ok=True)
os.makedirs(NPZ_DIR, exist_ok=True)
os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(STACK_DIR, exist_ok=True)

PATHS = ['EPPD', 'EGoD']
YEARS = list(range(1950, 2101, 1))
SSPS = ['ssp126', 'ssp245', 'ssp370', 'ssp585']

palette = sns.color_palette("Set2", len(METALS))
COLOR_MAP = dict(zip(METALS, palette))

# ========================== Core Scaling Functions ==========================

def scale_by_global_max(data_dict, max_val):
    """
    Recursively scales all numerical values in a nested dictionary by a maximum value.
    """
    if max_val == 0: 
        return data_dict
        
    new_dict = copy.deepcopy(data_dict)
    
    def update(sub_dict):
        for k, v in sub_dict.items():
            if isinstance(v, dict):
                update(v)
            elif isinstance(v, np.ndarray):
                sub_dict[k] = v / max_val
            elif isinstance(v, (int, float, np.number)):
                sub_dict[k] = v / max_val
                
    update(new_dict)
    return new_dict

def scale_dict_by_path(data_dict, path_max_dict):
    """
    Scales a multi-dimensional dictionary independently based on specific pathway limits.
    Assumes dict structure: dict[ssp][path][year] = value
    """
    new_dict = copy.deepcopy(data_dict)
    for ssp in new_dict:
        for path_name, max_val in path_max_dict.items():
            if path_name in new_dict[ssp] and max_val > 0:
                new_dict[ssp][path_name] = scale_by_global_max(new_dict[ssp][path_name], max_val)
    return new_dict

def cr_total_to_cr6_fast(cr_total):
    """
    Converts Total Chromium concentration to Hexavalent Chromium (Cr6+) 
    using established empirical ratios.
    """
    cr_ng_m3 = cr_total * 1000.0
    conditions = [
        cr_ng_m3 >= 8, 
        (cr_ng_m3 >= 6) & (cr_ng_m3 < 8),
        (cr_ng_m3 >= 4) & (cr_ng_m3 < 6), 
        (cr_ng_m3 >= 2) & (cr_ng_m3 < 4),
        (cr_ng_m3 >= 1) & (cr_ng_m3 < 2), 
        cr_ng_m3 < 1
    ]
    ratios = [0.0160, 0.0215, 0.0327, 0.0445, 0.0657, 0.1416]
    ratio = np.select(conditions, ratios, default=0.1416)
    return cr_ng_m3 / 1000.0 * ratio


# ========================== Data Loading & Preprocessing ==========================

class DataLoader:
    """
    Handles the preloading and alignment of spatial, demographic, 
    and environmental exposure data.
    """
    def __init__(self):
        self.metal_cache = {} 
        self.grid_area = None 
        self.lat = None
        self.lon = None
        self.pds_df_cache = {} 
        self._init_id_map()

    def _init_id_map(self):
        org_id = pd.read_excel(EXPOSURE_XLSX)
        if 'Exposure_ID' not in org_id.columns:
            org_id.columns = ['input_id', 'exid', 'Exposure_ID', 'preferred_name', 'unified_name', 'CAS'][:len(org_id.columns)]
        
        self.id_map = (org_id[['Exposure_ID', 'unified_name']]
                       .drop_duplicates()
                       .assign(unified_name=lambda d: d['unified_name'].astype(str).str.lower())
                       .set_index('Exposure_ID')['unified_name']
                       .to_dict())

    def preload_pds_tables(self):
        for path_name in PATHS:
            in_path = os.path.join(EBIO_DIR, f'path_diversity_score_{path_name}/exposure_disease_path_diversity_scores.csv')
            df = pd.read_csv(in_path)
            df['Exposure_Name'] = df['Exposure_ID'].map(self.id_map).fillna(df.get('Exposure_Name', ''))
            df['Exposure_Name'] = df['Exposure_Name'].astype(str).str.lower()
            df.loc[df['Exposure_Name'].eq('cr'), 'Exposure_Name'] = 'cr6'
            self.pds_df_cache[path_name] = df
        print("Pathway Diversity Score (PDS) weight tables loaded successfully.")

    def _calculate_grid_area(self, lats, grid_res=0.25):
        R = 6371.0 # Earth's radius in km
        dlat_km = np.deg2rad(grid_res) * R
        dlon_km = np.deg2rad(grid_res) * R * np.cos(np.deg2rad(lats))
        area = np.where((dlat_km * dlon_km) <= 0, 1e-6, dlat_km * dlon_km)
        return area

    def load_metal_data(self, ssp):
        print(f"Preloading metal concentration data for scenario {ssp.upper()}...")
        cache = {}
        for m in ['as', 'pb', 'cd', 'bap', 'cr']:
            xls = pd.ExcelFile(os.path.join(PRED_DIR, f'{m}_0.25_annual_1950_2100_byScenario.xlsx'))
            sheets_needed, year_map = set(), {}
            
            for y in YEARS:
                if m in ['as', 'pb', 'cd', 'cr']: 
                    sheet = 'history' if y < 2012 else ('present' if y < 2018 else ssp)
                else: 
                    sheet = 'history' if y < 2015 else ssp
                sheets_needed.add(sheet)
                year_map[y] = sheet

            dfs = {sheet: xls.parse(sheet).sort_values(by=['lat', 'lon']).reset_index(drop=True) for sheet in sorted(list(sheets_needed))}
            
            if self.lat is None:
                self.lat, self.lon = dfs[sorted(list(sheets_needed))[0]]['lat'].values, dfs[sorted(list(sheets_needed))[0]]['lon'].values
                print(f"Global spatial reference coordinates locked. Total grids: {len(self.lat)}")

            cache[m] = {}
            for y in YEARS:
                try:
                    vals = dfs[year_map[y]][str(y)].to_numpy(dtype=float)
                    if m == 'cr': 
                        vals, key = cr_total_to_cr6_fast(vals), 'cr6'
                    elif m == 'bap': 
                        vals, key = vals / 1000.0, 'bap'
                    else: 
                        key = m
                    
                    if key not in cache: cache[key] = {}
                    cache[key][y] = vals
                except KeyError: 
                    pass
                    
        self.metal_cache[ssp] = cache
        print(f"Metal concentration data for {ssp.upper()} loaded successfully.")

    def get_pop_density(self, year, ssp):
        pop_ssp = ssp[:4].upper()
        if 1950 <= year <= 2010: 
            fname = 'history_population_1950_2010_annual.csv'
        elif 2010 <= year <= 2020: 
            fname = f'{pop_ssp}_population_2010_2020.csv'
        else: 
            fname = f'{pop_ssp}_population_2020_2100_annual.csv'
        
        pop_df = pd.read_csv(os.path.join(POP_PATH, fname))
        pop_df.columns = pop_df.columns.str.strip()
        
        target_col = next((c for c in pop_df.columns if str(year) in c), pop_df.columns[-1])
        pop_df = pop_df.sort_values(by=['lat', 'lon']).reset_index(drop=True)
        
        if self.grid_area is None:
            self.grid_area = self._calculate_grid_area(pop_df['lat'].to_numpy())
            
        pop_values = np.nan_to_num(pop_df[target_col].to_numpy(dtype=float), nan=0.0)
        with np.errstate(divide='ignore', invalid='ignore'):
            pop_density = np.where(pop_values == 0, 0.0, pop_values / self.grid_area)
            
        return pop_values, pop_density

def build_spatial_index(loader, shp_path):
    """
    Constructs a spatial index matching point coordinates to provincial polygons.
    """
    print("Constructing spatial index for provincial aggregation...")
    gdf_prov = gpd.read_file(shp_path).to_crs("EPSG:4326")
    prov_col = 'shapeName' if 'shapeName' in gdf_prov.columns else 'name'
    
    gdf_points = gpd.GeoDataFrame(
        index=np.arange(len(loader.lon)), 
        geometry=gpd.points_from_xy(loader.lon, loader.lat), 
        crs="EPSG:4326"
    )
    
    gdf_joined = gpd.sjoin(gdf_points, gdf_prov[[prov_col, 'geometry']], how="inner", predicate="within")
    prov_index_dict = {prov: gdf_joined[gdf_joined[prov_col] == prov].index.values for prov in gdf_joined[prov_col].unique()}
    print(f"Spatial index completed. Covering {len(prov_index_dict)} administrative regions.")
    return prov_index_dict


# ========================== Main Execution Routine ==========================

def main():
    # Initialize Data Loader
    loader = DataLoader()
    loader.preload_pds_tables()
    loader.load_metal_data('ssp126')
    prov_index_dict = build_spatial_index(loader, SHP_PATH)
    
    province_risk_results, all_stack_data = [], []
    
    # Initialize data storage dictionaries
    dicts = {
        'sum': {ssp: {path: {} for path in PATHS} for ssp in SSPS},
        'ind_score': {ssp: {path: {} for path in PATHS} for ssp in SSPS},
        'spa_score': {ssp: {path: {} for path in PATHS} for ssp in SSPS},
        'ind_spa_score': {ssp: {path: {} for path in PATHS} for ssp in SSPS},
        'eds_spa': {ssp: {path: {} for path in PATHS} for ssp in SSPS},
        'eds_ind_spa': {ssp: {path: {} for path in PATHS} for ssp in SSPS},
        'conc_spa': {ssp: {} for ssp in SSPS}
    }

    # Tracking Global Maximums for normalization by specific pathway
    GLOBAL_MAX_SINGLE_DISEASE_RISK = {path: 0.0 for path in PATHS}
    GLOBAL_MAX_INFO = {
        path: {"Disease_Name": "", "SSP": "", "Year": 0} for path in PATHS
    }

    # Phase 1: Absolute value computation and aggregation
    for ssp in SSPS:
        print(f"\n--- Processing Scenario: {ssp.upper()} ---")
        loader.load_metal_data(ssp) 
        
        for year in tqdm(YEARS, desc=f"Computing {ssp.upper()}"):
            curr_metals = {m: loader.metal_cache[ssp][m][year] for m in METALS}
            dicts['conc_spa'][ssp][year] = np.sum(list(curr_metals.values()), axis=0)
            
            pop_values, _ = loader.get_pop_density(year, ssp)
            if isinstance(pop_values, tuple): 
                pop_values = pop_values[0]

            for path_name in PATHS:
                df_pds = loader.pds_df_cache[path_name]
                quali_disease = df_pds.groupby('Disease_ID').size()[lambda x: x == 5].index.tolist()
                rows_buffer = []

                # Iterate through qualified diseases
                for disease_id, sub in df_pds[df_pds['Disease_ID'].isin(quali_disease)].groupby('Disease_ID'):
                    if not set(METALS).issubset(set(sub['Exposure_Name'].unique())): 
                        continue
                    
                    disease_spatial_total = np.zeros_like(pop_values) # Risk without population (EPD)
                    eds_spatial_total = np.zeros_like(pop_values)     # Risk with population (EDS)
                    total_weighted_acc = 0
                    temp_storage = []
                    
                    for _, r in sub.iterrows():
                        m = r['Exposure_Name']
                        if m not in curr_metals: 
                            continue 
                            
                        conc_std = curr_metals[m] / REF[m]
                        pds_w = float(r['PDS_Weighted'])
                        
                        weighted_score_no_pop = conc_std * pds_w        # EPD calculation
                        weighted_score = weighted_score_no_pop * pop_values # EDS calculation
                        
                        disease_spatial_total += weighted_score_no_pop
                        eds_spatial_total += weighted_score
                        total_weighted_acc += weighted_score.sum()
                        
                        temp_storage.append({
                            'row': r, 
                            'raw_val': curr_metals[m].sum(), 
                            'pop_val': (conc_std * pop_values).sum(), 
                            'sw_val': weighted_score.sum()
                        })

                    # Update pathway-specific global maximums
                    current_disease_max = np.max(disease_spatial_total)
                    if current_disease_max > GLOBAL_MAX_SINGLE_DISEASE_RISK[path_name]:
                        GLOBAL_MAX_SINGLE_DISEASE_RISK[path_name] = current_disease_max
                        
                        disease_name = sub['Disease_Name'].iloc[0]
                        GLOBAL_MAX_INFO[path_name]["Disease_Name"] = disease_name
                        GLOBAL_MAX_INFO[path_name]["SSP"] = ssp
                        GLOBAL_MAX_INFO[path_name]["Year"] = year

                    for item in temp_storage:
                        r = item['row']
                        pct = item['sw_val'] / total_weighted_acc if total_weighted_acc != 0 else 0
                        rows_buffer.append({
                            'Disease_ID': disease_id, 
                            'Disease_Name': r['Disease_Name'], 
                            'Exposure_Name': r['Exposure_Name'],
                            'metal_raw_score': item['raw_val'], 
                            'metal_pop_score': item['pop_val'], 
                            'metal_weighted_score': item['sw_val'], 
                            'disease_total_weighted_score': total_weighted_acc, 
                            'percent_contribution': pct,
                            'weighted_score_without_pop': disease_spatial_total, 
                            'weighted_score': eds_spatial_total 
                        })

                df_res = pd.DataFrame(rows_buffer)
                if df_res.empty: 
                    continue

                # Extract and aggregate provincial-level data
                unique_diseases_df = df_res.groupby('Disease_Name').first().reset_index()
                for _, row in unique_diseases_df.iterrows():
                    for prov_name, indices in prov_index_dict.items():
                        p_risk = row['weighted_score_without_pop'][indices]
                        p_eds = row['weighted_score'][indices]
                        if len(p_risk) > 0:
                            province_risk_results.append({
                                'SSP': ssp, 'Year': year, 'Path': path_name, 
                                'Province': prov_name, 'Disease': row['Disease_Name'],
                                'Risk_Score_Total': np.sum(p_risk), 'EDS_Total': np.sum(p_eds),
                                'Risk_Score_Mean': np.mean(p_risk), 'EDS_Mean': np.mean(p_eds), 
                                'Grid_Count': len(p_risk)
                            })

                # Store aggregated spatial and individual scores
                d_grouped = df_res.groupby('Disease_Name')
                dicts['sum'][ssp][path_name][year] = d_grouped['disease_total_weighted_score'].first().sum()
                dicts['ind_score'][ssp][path_name][year] = d_grouped['disease_total_weighted_score'].first().to_dict()
                dicts['spa_score'][ssp][path_name][year] = np.sum(np.stack(d_grouped['weighted_score_without_pop'].first().values), axis=0)
                dicts['ind_spa_score'][ssp][path_name][year] = d_grouped['weighted_score_without_pop'].first().to_dict()
                dicts['eds_spa'][ssp][path_name][year] = np.sum(np.stack(d_grouped['weighted_score'].first().values), axis=0)
                dicts['eds_ind_spa'][ssp][path_name][year] = d_grouped['weighted_score'].first().to_dict()
                
                # Store data for stacked area plots
                stack_df = df_res.drop(columns=['weighted_score_without_pop', 'weighted_score'], errors='ignore')
                all_stack_data.append({'ssp': ssp, 'year': year, 'path': path_name, 'df': stack_df})

        if ssp in loader.metal_cache:
            del loader.metal_cache[ssp] 

    # Phase 2: Pathway-Specific Normalization and Serialization
    print("\n------------------------------------------------------------")
    print("Primary computation complete. Generating baseline normalization records...")
    
    baseline_record_path = os.path.join(NPZ_DIR, "baseline_normalization_info.txt")
    with open(baseline_record_path, "w", encoding="utf-8") as f:
        f.write("Global Normalization Baseline Record (By Path)\n")
        f.write("==============================================\n")
        
        for path_name in PATHS:
            max_val = GLOBAL_MAX_SINGLE_DISEASE_RISK[path_name]
            info = GLOBAL_MAX_INFO[path_name]
            print(f"Path [{path_name}]:")
            print(f"  - Max Value (Denominator): {max_val:.6f}")
            print(f"  - Associated Disease: {info['Disease_Name']}")
            print(f"  - Origin Scenario: {info['SSP'].upper()} ({info['Year']})\n")
            
            f.write(f"\nPATH: {path_name}\n")
            f.write(f"Global Max Single Disease Risk (Denominator): {max_val:.6f}\n")
            f.write(f"Source Disease: {info['Disease_Name']}\n")
            f.write(f"Source SSP: {info['SSP']}\n")
            f.write(f"Source Year: {info['Year']}\n")
            
    print(f"Baseline metadata saved to: {baseline_record_path}")
    print("------------------------------------------------------------\n")
    print("Applying specific normalization limits across output matrices...")

    # 1. Normalize provincial tabular data
    df_prov = pd.DataFrame(province_risk_results)
    if not df_prov.empty:
        for path_name in PATHS:
            max_val = GLOBAL_MAX_SINGLE_DISEASE_RISK[path_name]
            if max_val > 0:
                mask = df_prov['Path'] == path_name
                for col in ['Risk_Score_Total', 'EDS_Total', 'Risk_Score_Mean', 'EDS_Mean']:
                    df_prov.loc[mask, col] = df_prov.loc[mask, col] / max_val
                
                # Export normalized results by pathway
                sub_df = df_prov[mask]
                sub_df.to_csv(os.path.join(NPZ_DIR, f'Province_Disease_Risks_Summary_{path_name}.csv'), index=False)

    # 2. Normalize and export stacked plot data arrays
    if all_stack_data:
        stack_cols = ['metal_raw_score', 'metal_pop_score', 'metal_weighted_score', 'disease_total_weighted_score']
        for item in all_stack_data:
            path_name = item['path']
            max_val = GLOBAL_MAX_SINGLE_DISEASE_RISK[path_name]
            
            if max_val > 0:
                sdf = item['df'].copy()
                for col in stack_cols:
                    sdf[col] = sdf[col] / max_val
                np.savez_compressed(
                    os.path.join(NPZ_DIR, f"{item['ssp']}_{item['year']}_{path_name}_stack_data.npz"), 
                    **{str(c): sdf[c].values for c in sdf.columns}
                )

    # 3. Normalize dictionaries using dedicated pathway scaling utility
    # Note: 'conc_spa' (raw concentration) has no PDS context and remains unscaled.
    joblib.dump(scale_dict_by_path(dicts['sum'], GLOBAL_MAX_SINGLE_DISEASE_RISK), os.path.join(NPZ_DIR, 'sum_score_dict.joblib'))
    joblib.dump(scale_dict_by_path(dicts['ind_score'], GLOBAL_MAX_SINGLE_DISEASE_RISK), os.path.join(NPZ_DIR, 'individual_disease_score_dict.joblib'))
    joblib.dump(scale_dict_by_path(dicts['spa_score'], GLOBAL_MAX_SINGLE_DISEASE_RISK), os.path.join(NPZ_DIR, 'spatial_score_dict.joblib'))
    joblib.dump(scale_dict_by_path(dicts['ind_spa_score'], GLOBAL_MAX_SINGLE_DISEASE_RISK), os.path.join(NPZ_DIR, 'individual_disease_spatial_score_dict.joblib'))
    joblib.dump(scale_dict_by_path(dicts['eds_spa'], GLOBAL_MAX_SINGLE_DISEASE_RISK), os.path.join(NPZ_DIR, 'eds_spatial_score_dict.joblib'))
    joblib.dump(scale_dict_by_path(dicts['eds_ind_spa'], GLOBAL_MAX_SINGLE_DISEASE_RISK), os.path.join(NPZ_DIR, 'eds_individual_disease_spatial_score_dict.joblib'))
    joblib.dump(dicts['conc_spa'], os.path.join(NPZ_DIR, 'conc_spatial_dict.joblib'))

    # 4. Serialize DataLoader object state
    with open(os.path.join(NPZ_DIR, 'loader_object.pkl'), 'wb') as f: 
        pickle.dump(loader, f)
    
    print("\nAll computations and pathway-specific normalization completed successfully.")

if __name__ == "__main__":
    main()



